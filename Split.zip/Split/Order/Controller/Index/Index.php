<?php
namespace Split\Order\Controller\Index;

use Magento\Quote\Model\QuoteManagement;
use Magento\Framework\Exception\LocalizedException;
use Magento\Quote\Api\CartRepositoryInterface;
use Magento\Quote\Model\QuoteFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Framework\Event\ManagerInterface;

class Index extends \Magento\Framework\App\Action\Action
{
   
    private $checkoutSession;
    /**
     * @var CartRepositoryInterface
     */
    private $quoteRepository;

    /**
     * @var QuoteFactory
     */
    private $quoteFactory;

    /**
     * @var ManagerInterface
     */
   
    private $quoteHandler;

    protected $logger;
	protected $_pageFactory;

	public function __construct(
		CartRepositoryInterface $quoteRepository,
        QuoteFactory $quoteFactory,
        ManagerInterface $eventManager,
        
        \Psr\Log\LoggerInterface $logger,
        CheckoutSession $checkoutSession,
		\Magento\Framework\App\Action\Context $context,
         \Split\Order\Helper\Data $helperData,

		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->quoteRepository = $quoteRepository;
        $this->quoteFactory = $quoteFactory;
        $this->eventManager = $eventManager;
        $this->checkoutSession = $checkoutSession;
        $this->helperData = $helperData;
        //$this->quoteHandler = $quoteHandler;
        $this->logger = $logger;
		return parent::__construct($context);
	}

	public function execute()
	{   
    $order = [

    'currency_id' => 'USD',

    'email' => 'hello@example.com',

    'shipping_address' => ['firstname' => 'John',

        'lastname' => 'Green',

        'street' => 'xxxxxx',

        'city' => 'xxxxxxx',

        'country_id' => 'US',

        'region' => 'xxxxx',
         'region_id' => '25',
         'flatrate_flatrate' =>'Flat Rate',

        'postcode' => '85001',

        'telephone' => '52556542',

        'fax' => '3242322556',

        'save_in_address_book' => 1],

    'items' => [

        ['product_id' => '1', 'price' => 250 , 'qty' => 1],

        ['product_id' => '2', 'price' => 250 , 'qty' => 2]]

    ];
    /*'shipping_method' =>[

    ]*/
 

        $this->helperData->createOrder($order);
    return;     
		//$this->getQouteId();
	
	}
	public function getQouteId()
    {
         $quoteId = $this->checkoutSession->getQuote()->getId();
            //$ids = $this->checkoutSession->getQuote();
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$_quoteRepository = $objectManager->create('\Magento\Quote\Model\QuoteRepository');
		$ids = $_quoteRepository->get($quoteId);
		
        $allItems = $ids->getAllVisibleItems();
        //print_r(get_class_methods($ids));exit;
         $quotes = [];
        foreach ($allItems as $item) {
         //echo $item->getProductId();
        	$quotes[]=$item->getProduct()->getSku();
          print_r($quotes);
          //print_r($quotes);
       }
   }
}