<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Order\Attachments\Controller\Index;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;


class Index extends \Magento\Framework\App\Action\Action
{
    /**
     * Show Contact Us page
     *
     * @return void
     */
    protected $quoteFactory;
    protected $checkoutSession;
    protected $_objectManager;
    protected $_storeManager;
    protected $_filesystem;
    protected $_fileUploaderFactory;
    
    public function __construct(
    	\Magento\Framework\App\Action\Context $context, \Magento\Framework\ObjectManagerInterface $objectManager, StoreManagerInterface $storeManager,\Magento\Framework\Filesystem $filesystem, \Magento\Quote\Model\QuoteFactory $quoteFactory,\Magento\Checkout\Model\Session $checkoutSession,\Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory) 
    {
    	$this->quoteFactory = $quoteFactory;
    	$this->checkoutSession = $checkoutSession;
        $this->_objectManager = $objectManager;
        $this->_storeManager = $storeManager;
        $this->_filesystem = $filesystem;
        $this->_fileUploaderFactory = $fileUploaderFactory;
        parent::__construct($context);    
    }

    public function execute()
    {
    	$quoteId=$this->checkoutSession->getQuote()->getId();
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $_quoteRepository = $objectManager->create('\Magento\Quote\Model\QuoteRepository');
        $ids = $_quoteRepository->get($quoteId);
    	//echo "dddddd";
    	//print_r($quoteId->getData()); exit;
        //$model=$this->quoteFactory->create()->loadByIdWithoutStore($quoteId);
    	//$model=$this->quoteFactory->create()->loadByIdWithoutStore($quoteId);
    	//print_r(get_class_methods($model));exit;
        $post = $this->getRequest()->getPostValue();
        $files     = $this->getRequest()->getFiles('attachment');
        echo $files['name'];exit;
        $fileName = $files['name'];
        $ids->setData('attachment', $fileName);
           
             $ids->save();
       
      echo "sssssss";
         
       /* $redirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
        $storeUrl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
	    $redirect->setUrl($storeUrl.'/checkout#shipping');

	    return $redirect;*/
       
       
    }
}