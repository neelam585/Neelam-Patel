define([
    'ko',
	'jQuery',
    'uiComponent'
], function (ko, $, Component) {
    'use strict';
 alert('cccccccccccccccc');
 


    return Component.extend({
        defaults: {
            template: 'Order_Attachments/customtemp'
        }
		
    });
	
});