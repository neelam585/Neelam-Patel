<?php
namespace Banner\Grid\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\Message\ManagerInterface;
class BeforePlaceOrderObserver implements ObserverInterface {


    protected $messageManager;

    public function __construct(
        
        ManagerInterface $messageManager
    ) {
        
        $this->messageManager          = $messageManager;
    }
    public function execute(Observer $observer) {

    	/*$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
$messageManager = $objectManager->get('Magento\Framework\Message\ManagerInterface')
$messageManager->addError(__("Error"));*/

    	$writer = new \Zend\Log\Writer\Stream(BP . '/var/log/customfile.log');
$logger = new \Zend\Log\Logger();
$logger->addWriter($writer);
$logger->info('hello gggggggggggg');

$message = __('Error Messagefhfghg');
$this->messageManager->addErrorMessage($message);
           
exit;
        /*die("Error Message");
        exit;*/
    }
}