/**
 * Created By : Rohan Hapani
 */
var config = {
    paths: {
        owlcarousel: "Banner_Grid/js/owl.carousel"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};
