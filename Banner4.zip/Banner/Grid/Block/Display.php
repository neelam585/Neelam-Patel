<?php
namespace Banner\Grid\Block;

class Display extends \Magento\Framework\View\Element\Template
{
	protected $_postFactory;

	public function __construct(
		\Magento\Framework\View\Element\Template\Context $context,
        \Banner\Grid\Model\PostFactory $postFactory 
	)
	{
		$this->_postFactory = $postFactory;
		parent::__construct($context);
	}

	public function displayBanner()
	{
		$post = $this->_postFactory->create();
		$collection = $post->getCollection();
		return $collection;
		
	}
}
