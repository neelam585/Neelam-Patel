<?php
$helper = $this->helper('Frontend\Crud\Helper\Data');
$status = $helper->isEnabled();
//echo $status;exit;
$data = $block->getEditData(); 
$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
$mediaUrl = $objectManager->get('Magento\Store\Model\StoreManagerInterface')
                    ->getStore()
                    ->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
?>
<?php if($status == 1){?>
 <a class="action primary" id="modal-btn">Add Record</a>
<?php } ?>
<table>
    <tr>
        <th><?= __('Title'); ?></th>
        <th><?= __('Image'); ?></th>
        <th><?= __('Status No'); ?></th>
        
        <th colspan="2"><?= __('Action'); ?></th>
    </tr>
    <?php
        $collectionData = $block->getTableData();
        foreach($collectionData as $collection):
    ?>
    <tr>
        <td><?= $collection->getTitle(); ?></td>
        
        <td>
                <?php $v  = $mediaUrl."image/".$collection->getImage();?>
          
                <img src='<?php echo $v; ?>' height=50px width= 50px/>
        </td>
        <td><?= $collection->getStatus(); ?></td>
        
        <td>
            <button class="del btn btn-danger edit" id="<?= $collection->getData('post_id');?>">Edit
            
        </td>
        <td>
            <button class="del btn btn-danger delete" id="<?= $collection->getData('post_id');?>">Delete</button>
            
        </td> 
    </tr>
    <?php endforeach; ?>
</table>

<div id="edit-content" style="display: none;">
    <div class="modal-inner-content">
        <form id="abcd" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Title:</label>
                <input type="name" class="form-control" id="title" placeholder="Enter Title" name="title" value="">
            </div>
            <div class="form-group">
                <label for="email">Image:</label>
                <input type="file" class="form-control" id="image" name="image">
            </div>
            <div>
              <input type="radio" id="yes" name="status" value="Yes">
              <label for="huey">Yes</label>
              <input type="radio" id="no" name="status" value="No"
                     >
              <label for="huey">No</label>
            </div>
            <br><br>
            <input type="submit" class="action primary" id="model-button" name="submit" value="Submit">
        </form>
    </div>
</div>

<div id="modal-content">
    <div class="modal-inner-content">
        <form id="abcd" action="" enctype="multipart/form-data">
            <div class="form-group">
                <label for="name">Title:</label>
                <input type="name" class="form-control" id="title" placeholder="Enter Title" name="title" value="">
            </div>
            <div class="form-group">
                <label for="email">Image:</label>
                <input type="file" class="form-control" id="image" name="image">
            </div>
            <div>
              <input type="radio" id="yes" name="status" value="Yes"
                     >
              <label for="huey">Yes</label>
              <input type="radio" id="no" name="status" value="No"
                     checked>
              <label for="huey">No</label>
            </div>
            <br><br>
            <input type="submit" class="action primary" id="model-button" name="submit" value="Submit">
        </form>
    </div>
</div>
