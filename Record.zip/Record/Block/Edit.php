<?php
 namespace Frontend\Record\Block;
 
class Edit extends \Magento\Framework\View\Element\Template
{
     protected $_pageFactory;
     protected $_coreRegistry;
     protected$_gridtestFactory;
 
     public function __construct(
          \Magento\Framework\View\Element\Template\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Magento\Framework\Registry $coreRegistry,
          \Banner\Grid\Model\GridtestFactory $gridtestFactory,
          array $data = []
     ){
          $this->_pageFactory = $pageFactory;
          $this->_coreRegistry = $coreRegistry;
          $this->_gridtestFactory = $gridtestFactory;
          return parent::__construct($context,$data);
          //return parent::__construct($postFactory,$data);
     }
 
     public function execute()
     {
          return $this->_pageFactory->create();
     }
 
     public function getEditData()
     {
          //getRegistryVariable
          $id = $this->_coreRegistry->registry('editId');
          $postData = $this->_gridtestFactory->create();
          $result = $postData->load($id);
          //print_r($result);exit;
         $result = $result->getData();
          return $result;
     }
}
