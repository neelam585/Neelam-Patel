<?php
namespace Frontend\Record\Block;
 
use Magento\Framework\View\Element\Template;
use Banner\Grid\Model\GridtestFactory;
 
class Index extends Template
{
    protected $_gridtestFactory;
 
    public function __construct(
        Template\Context $context,
        GridtestFactory $gridtestFactory
    ) {
        parent::__construct($context);
        $this->_gridtestFactory = $gridtestFactory;
    }
 
    public function getTableData()
    {
        $contact = $this->_gridtestFactory->create();
        $collection = $contact->getCollection();
        
        return $collection;
    }
}
