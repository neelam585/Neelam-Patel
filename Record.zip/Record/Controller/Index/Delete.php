<?php
 
namespace Frontend\Record\Controller\Index;
 
class Delete extends \Magento\Framework\App\Action\Action
{
     protected $_pageFactory;
     protected $_request;
     protected $_gridtestFactory;
 
     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Magento\Framework\App\Request\Http $request,
          \Banner\Grid\Model\GridtestFactory $gridtestFactory
          
     ){
          $this->_pageFactory = $pageFactory;
          $this->_request = $request;
          $this->_gridtestFactory = $gridtestFactory;
          return parent::__construct($context);
     }
 
     public function execute()
     {
          $id = $this->_request->getParam('id');
          //echo $id.'sssssss';exit;
          $postData = $this->_gridtestFactory->create();
           
          $result = $postData->setId($id);
         
          $result = $result->delete();
          return $this->_redirect('crud/index/index');
     }
}
