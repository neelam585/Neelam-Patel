<?php
 
namespace Frontend\Record\Controller\Index;
 
class Save extends \Magento\Framework\App\Action\Action
{
     protected $_pageFactory;
     protected $_gridtestFactory;
 
     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Banner\Grid\Model\GridtestFactory $gridtestFactory
     ){
          $this->_pageFactory = $pageFactory;
          $this->_gridtestFactory = $gridtestFactory;
          return parent::__construct($context);
     }
 
     public function execute()
     {
         if ($this->getRequest()->isPost()) {
               $input = $this->getRequest()->getPostValue();
                //print_r($input);die;  
               $postData = $this->_gridtestFactory->create();
               if($input['editId']){
                    $postData->load($input['editId']);
                    $postData->setData($input);
                    $postData->setId($input['editId']);
                    $postData->save();
               }else{
                    $postData->setData($input)->save();
               }
               return $this->_redirect('record/index/index');
          }
     }
}