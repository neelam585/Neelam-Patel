<?php

namespace Pharmacy\Validation\Plugin\Block\Checkout;
use Magento\Checkout\Block\Checkout\AttributeMerger;

class PhonePlugin
{
    /**
     * @param AttributeMerger $subject
     * @param $result
     * @return mixed
     */
    public function afterMerge(AttributeMerger $subject, $result)
    {
        $result['telephone']['validation'] = [
            //'required-entry'  => true,
            //'phoneUS' =>true,
            'min_text_length' => 12,
            'max_text_length' => 12
            //'phone-hypen' => 10
            //'validate-phoneStrict' =>true,
            //'validate-fax' =>true,
           /* 'custom-validate-telephone' => true,*/
            //'validate-phoneLax' => true
        ];
        return $result;
    }
}
