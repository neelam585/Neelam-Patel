define([
    'ko',
    'jquery',
    'uiComponent'
], function (ko, $, Component) {
    'use strict';
 
 //var configValues = window.checkoutConfig;
        //console.log(configValues.test);//here test is the field name which you passed in $config variable
 

    return Component.extend({
        defaults: {
            template: 'Order_Attachments/customtemp',
            x : ko.observable(true),
            status:ko.observable(valuesConfig)
        },
        /*getValues: function() {  alert(this.status());
        console.log(this.status());
      return window.valuesConfig;
        },*/
        initialize: function(){
            this._super();
            this.showField();
            this.hideField();
            
            //alert('ttttttttttttt');
            $.noConflict(); 
    var formdata = new FormData();      
    $(document).on("change",'#attachment', function() {
        //alert("hello");
        var file = this.files[0];
        //var name = jQuery("#name").val();
        if (formdata) {
            formdata.append("image", file);
            //formdata.append("name", name);
            $.ajax({
                url: "http://127.0.0.1/M24/order/index/index",
                type: 'POST',
                mimeTypes: 'multipart/form-data',
                data: formdata,
                processData: false,
                contentType: false,
                success:function(respons){
                    alert(respons);
                }
            });
        }                       
            }); 
            
    },
            showField: function(){
                 $(document).on("change",'#yes', function() {
            
            $(".special-comments").show();
         });  
        },
            hideField: function(){
                 $(document).on("change",'#no', function() {
            
            $(".special-comments").hide();
         });  
        }
    });
    
    
});
