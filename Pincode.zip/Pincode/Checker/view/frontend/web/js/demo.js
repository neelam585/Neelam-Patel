define(['jquery', 'uiComponent', 'ko'], function ($, Component, ko) {
'use strict';
return Component.extend({
defaults: {
template: 'Pincode_Checker/demo',
x : ko.observable(true),
},
initialize: function () {
this._super();
},
getCall:function(){
	alert(this.status);
}
});
}
);