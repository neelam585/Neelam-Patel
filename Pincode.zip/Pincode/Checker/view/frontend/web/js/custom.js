require([
        'mage/url',
        'jquery', 
        'Magento_Ui/js/modal/modal',
        'Magento_Ui/js/modal/confirm'
    ], function(urlBuilder, $, modal, confirmation) {
  "use strict";
  var customLink = urlBuilder.build('pincode/index/index');
  console.log(customLink);
  $(document).ready(function() {
    $("#check").on('click', function(){
      var customLink = urlBuilder.build('pincode/index/index');
      var pincode = $('#pincode').val();  
       

              $.ajax({
                        url: customLink,
                        data:{pincode:pincode},
                        type: 'POST',
                        dataType: 'json',
                    success: function(data) {
                        if(data == true){
              $('#msgs').html('Delivery Available');
              }else{
              $('#msgs').html('Delivery Not Available');
                           }
                    }
 
  
          });
     });
  });
 });