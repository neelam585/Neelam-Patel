<?php
namespace Pincode\Checker\Block\Frontend;

class View extends \Magento\Framework\View\Element\Template
{
   /**
     * @var \My\Module\Helper\Data
   */
   protected $_dataHelper;

 /**
 * @param \Magento\Framework\View\Element\Template\Context $context
 * @param \My\Module\Helper\Data $dataHelper
 * @param array $data
 */
public function __construct(
    \Magento\Framework\View\Element\Template\Context $context,
    \Pincode\Checker\Helper\Data $dataHelper,
    array $data = []
) {
    $this->_dataHelper = $dataHelper;
    parent::__construct($context, $data);
}

public function canShowBlock()
{
    return $this->_dataHelper->isModuleEnabled();
}
}