<?php declare(strict_types=1);

 

/**

 * @author  Rakesh Jesadiya

 */

 

namespace Pincode\Checker\Plugin;

 

use Magento\Sales\Api\Data\OrderInterface;

use Magento\Sales\Api\OrderManagementInterface;

use Pincode\Checker\Helper\Data;

use Magento\Framework\UrlInterface;

use Magento\Framework\Controller\Result\RedirectFactory;

use Magento\Framework\App\ResponseFactory;

use Psr\Log\LoggerInterface;

use Magento\Framework\Exception\CouldNotSaveException;

 

/**

 * Class OrderManagement

 */

class OrderManagement

{

    /**

     * Variable for response factory

     *

     * @var ResponseFactory

     */

    protected $responseFactory;

 

    /**

     * Variable for getting url

     *

     * @var UrlInterface

     */

    protected $url;

    private $redirectFactory;

    /**

     * Logger for system log.

     *

     * @var LoggerInterface

     */

    protected $logger;

 

    public function __construct(

        Data                $helperData,

        ResponseFactory     $responseFactory,

        UrlInterface        $url,

        RedirectFactory $redirectFactory,

        \Magento\Framework\Controller\Result\RedirectFactory $resultRedirectFactory,

        LoggerInterface     $logger

       

    ) {

        $this->helperData          = $helperData;      

        $this->responseFactory     = $responseFactory;

        $this->url                 = $url;

        $this->redirectFactory = $redirectFactory;

        $this->resultRedirectFactory = $resultRedirectFactory;

        $this->logger              = $logger;

    }

 

    
 

    public function  beforePlace(\Magento\Sales\Model\Order $order){

        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/zend_debug.log');

        $logger = new \Zend\Log\Logger();

        $logger->addWriter($writer);

 

        $logger->info("Hello from beforePlace plugin!");

        $logger->info("Order ID:");

        $logger->info($order->getId());

       

        //$get3ds     = $this->helperData->getCheck3DS();

       // $logger->info("3ds value:" .$get3ds);

        //if($get3ds=='true'){

            $physicalLink = "<a href='https://api.nexiopaysandbox.com/mockGateway/v1/payments/redirect/dad4edcd-2924-4e43-b7c9-a224908ef153?'></a>";

            $logger->info("3ds url:" .$physicalLink);

            throw new CouldNotSaveException(__('Error',$physicalLink));

            return false;

        //}

    }

}