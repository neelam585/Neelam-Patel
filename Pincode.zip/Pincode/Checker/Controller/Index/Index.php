<?php
namespace Pincode\Checker\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
    protected $_postFactory;
    /**
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
    protected $logger;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Pincode\Checker\Model\PostFactory $postFactory,
		\Psr\Log\LoggerInterface $logger,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_pageFactory = $pageFactory;
		$this->_postFactory = $postFactory;
		$this->logger       = $logger;
		return parent::__construct($context);
	}

	public function execute()
	{ //echo "AAAAAA"; 
		 $postData = $this->getRequest()->getPost();
           //print_r($postData); exit;
        $pincodeCollection = $this->_postFactory->create()->getCollection()
                    ->addFieldToSelect("*")
                    ->addFieldToFilter("zipcode", array("eq" => $postData['pincode']))
                    ->load();
		
		$pincodeAvailable = (count($pincodeCollection));
		if($pincodeAvailable){
			echo true; exit;
		}else{
			echo false; exit;
		}
		
	}
}