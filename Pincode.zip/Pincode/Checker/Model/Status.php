<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
/**
 * Created By : Rohan Hapani
 */
namespace Pincode\Checker\Model;
class Status implements \Magento\Framework\Option\ArrayInterface
{
    const STATUS_ENABLED = 'yes';
    const STATUS_DISABLED = 'no';
    public function toOptionArray()
    {
        return [
            [
                self::STATUS_ENABLED => __('Yes'),
                self::STATUS_DISABLED => __('No'),
            ],
        ];
    }
    public static function getOptionArray()
    {
        return [
            self::STATUS_ENABLED => __('Yes'),
            self::STATUS_DISABLED => __('No'),
        ];
    }
}