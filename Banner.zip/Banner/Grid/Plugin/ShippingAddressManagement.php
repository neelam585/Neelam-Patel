<?php
namespace Banner\Grid\Plugin;

use Magento\Framework\UrlInterface;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Message\ManagerInterface;

class ShippingAddressManagement
{
    protected $quoteRepository;
    protected $orderCollectionFactory;
    protected $storeManager;
    protected $messageManager;

    public function __construct(
        QuoteRepository $quoteRepository,
        CollectionFactory $orderCollectionFactory,
        StoreManagerInterface $storeManager,
        ManagerInterface $messageManager
    ) {
        $this->quoteRepository          = $quoteRepository;
        $this->orderCollectionFactory   = $orderCollectionFactory;
        $this->storeManager             = $storeManager;
        $this->messageManager          = $messageManager;
    }

    /**
     * @param \Magento\Checkout\Model\ShippingInformationManagement $subject
     * @param $cartId
     * @param \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     */
    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
        
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/customfile.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('hello errtrgryr');

        $message = __('Error ggggggggggggg');
        $this->messageManager->addErrorMessage($message);
                   
        exit;
    }
}
