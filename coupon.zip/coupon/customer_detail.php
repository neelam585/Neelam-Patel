<?php
$con = mysqli_connect("localhost","root","","coupon");
//print_r($_POST);
$name = $_POST['name'];
$phone = $_POST['phone'];
$sql = "INSERT INTO customer (first_name, contact_no, amount) VALUES ('$name', '$phone','')";
$result = mysqli_query($con, $sql);

?>

