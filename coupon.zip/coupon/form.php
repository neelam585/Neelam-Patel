<!DOCTYPE html>
<html>
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/ui/1.11.3/jquery-ui.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<h2>HTML Forms</h2>


  <label for="coupon_code">Coupon Code:</label><br>
  <input type="text" id="coupon_code" name="coupon_code" value=""><br>
 
  <input type="submit" name="submit" id="submit" value="Submit">
 

<div id="one" style="height: 100px; width: 100px; background: green; display:none"></div>


</body>
</html>

  <script type="text/javascript">
        $(document).ready(function () {
        	$('#submit').click(function(event){

	            var serviceURL = '/Custom/coupon/db_connection.php';
	            var couponCode = $("#coupon_code").val();
	            $.ajax({
	                type: "POST",
	                url: serviceURL,
	                data:{'coupon_code': couponCode},
	                dataType: "json",
	                success:function(resultData){
	                $("#one").css("display","block");
	                $("#one").empty();
	                 $("#one").append(resultData);

	                }
	            });


             });

        	$(document).on('click',"#submit1",function(event){
        		//alert("sdfkljsdfkl");

	             var serviceURL = '/Custom/coupon/customer_detail.php';
	             var name = $("#name").val();
	             var phone = $("#phone").val();
	             $.ajax({
	                 type: "POST",
	                 url: serviceURL,
	                 data:{'name': name, 'phone': phone},
	                 dataType: "json",
	                 success:function(resultData){
	                 
	                 
	                 }
	             });
             });
         });
    </script>