<?php
$con = mysqli_connect("localhost","root","","coupon");

// Check connection
/*if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}else{
	echo "done";
}*/

$sql = "SELECT coupon_code FROM coupon";

$result = mysqli_query($con, $sql);

/*if (mysqli_num_rows($result) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($result)) {
    echo "coupon_code: " . $row["coupon_code"]. "<br>";
  }
} else {
  echo "0 results";
}*/
//print_r($_POST);exit;
if(isset($_POST["coupon_code"])){
	$code = $_POST["coupon_code"];
//echo $code;
	$sqll = "SELECT * FROM coupon where coupon_code=$code";
	$results = mysqli_query($con, $sqll);

if (mysqli_num_rows($results) > 0) {
  // output data of each row
  while($row = mysqli_fetch_assoc($results)) {
    $updateSql = "UPDATE coupon
SET status=1
WHERE coupon_code=$code";
$updateResult = mysqli_query($con, $updateSql);
//$data=$code;
$data ="<div style='background:red'>
<input type='text' name='name' id='name' value'' >
 <input type='text' name='phone' id='phone' value'' >
<input type='submit' name='submit1' id='submit1' value='submit' >
</div>";
echo json_encode($data);exit;
  }
} else {
	//$data=$code;
	$data ="<div style='background:red'>you can not use this coupon code</div>";

echo json_encode($data);exit;
  //echo "you can not use this coupon code";
}
	
}

?>