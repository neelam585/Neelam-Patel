<?php
$con = mysqli_connect("localhost","root","","coupon");
$sql = "SELECT coupon_code FROM coupon";

$result = mysqli_query($con, $sql);

if(isset($_POST["coupon_code"])){
	$code = $_POST["coupon_code"];

	$sqll = "SELECT * FROM coupon where coupon_code=$code";
	$results = mysqli_query($con, $sqll);

if (mysqli_num_rows($results) > 0) {
  
  while($row = mysqli_fetch_assoc($results)) {
    $updateSql = "UPDATE coupon
SET status=1
WHERE coupon_code=$code";
$updateResult = mysqli_query($con, $updateSql);

$data ="<div style='background:red'>
<input type='text' name='name' id='name' value'' >
 <input type='text' name='phone' id='phone' value'' >
<input type='submit' name='submit1' id='submit1' value='submit' >
</div>";
echo json_encode($data);exit;
  }
} else {
	
	$data ="<div style='background:red'>you can not use this coupon code</div>";

echo json_encode($data);exit;
 
}
	
}

?>