<?php
namespace Pharmacy\AdditionalPayment\Helper;
 
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\HTTP\Client\Curl;
use Pharmacy\AdditionalPayment\Helper\Data;
use Pharmacy\Log\Helper\LogStatus; 
class ApiRequest extends AbstractHelper
{
 
  /**
  * @var Curl
  */
  protected $curl;

  /**
  * @var Helper
  */
  protected $_datahelper;
  protected $helper;

  /**
   * Constant variable
   */
  const DEFAULT_CUST_PASS = "chetu@123";

  /**
   * Constant variable
   */
  const API_AUTH_USER = "Recept";

  /**
   * Constant variable
   */
  const API_AUTH_PASS = "Welcome123!";

   /**
   * Constant variable
   */
  const API_TOKEN_URL = "https://stagingtp.recepthealthcare.com:86/Login/";

   /**
   * Constant variable
   */
  const API_REQUEST_DATA_URL = "https://stagingtp.recepthealthcare.com:86/api/CustomerOrderDetails";

  /**
   * Constant variable
   */
  const API_PUSH_DATA_URL = "https://stagingtp.recepthealthcare.com:86/api/OrderPayment/OrderPaymentInfo";

  /**
   * Constant variable
   */
  const API_PUSH_ADDITIONAL_ADDRESS_URL = "https://stagingtp.recepthealthcare.com:86/api/OrderPayment/AddOrderPaymentShippingAddress";

  /**
   * Constant variable
   */
  const PUSH_API_REQUEST_RESPONSE_CUSTOM_LOG = "/var/log/push_api_request_response.log";
  /**
   * Constant variable
   */
  const PUSH_API_ORDER_PAYMENT_SHIPPING_ADDRESS_CUSTOM_LOG = "/var/log/orderPaymentShippingAddress.log";

  public function __construct(
    Context $context,
    Curl $curl,
    Data $dataHelper,
    LogStatus $helper
  ) {
    parent::__construct($context);
    $this->curl         = $curl;
    $this->_datahelper  = $dataHelper;
    $this->helper       = $helper;
  }
 
public function tokenRequest() {
      $loginData = json_encode([
        "UserName"  => self::API_AUTH_USER,
        "Password" =>  self::API_AUTH_PASS
      ]);
      $curl = curl_init();

      curl_setopt_array($curl, array(
      CURLOPT_URL => self::API_TOKEN_URL,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => $loginData,
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json'
      ),
    ));

    $response = curl_exec($curl);
   
    if (curl_errno($curl)) {
        echo "Error => ".$error_msg = curl_error($curl);
        exit;
    }

    curl_close($curl);

    return json_decode($response);
  }   

  public function dataRequest($ccid, $orderId) {
      $token = $this->tokenRequest()->token;
      $data = json_encode([
        "CCID"  => $ccid,
        "Order" => $orderId
      ]);
      $curl = curl_init();

      curl_setopt_array($curl, array(
      CURLOPT_URL => self::API_REQUEST_DATA_URL,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => $data,
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'Authorization: Bearer '.$token
      ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);

    return json_decode($response);
  }

  public function OrderPaymentInfodata($orderId) {
    $logStatus = $this->helper->isEnable();

    $writer = new \Zend\Log\Writer\Stream(BP . self::PUSH_API_REQUEST_RESPONSE_CUSTOM_LOG);
    $logger = new \Zend\Log\Logger();
    $logger->addWriter($writer);
    $logger->info('order data in array--');
    $token      = $this->tokenRequest()->token;
    $orderData  = $this->_datahelper->getOrderData($orderId);
    $logger->info(print_r($orderData, true));
    $postdata   = json_encode($orderData);
    $curl       = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_PORT => "86",
        CURLOPT_URL => self::API_PUSH_DATA_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $postdata,
        CURLOPT_HTTPHEADER => array(
              'Content-Type: application/json',
              'Authorization: Bearer '.$token
            ),
    ));

    $response = curl_exec($curl);
    $err      = curl_error($curl);

    curl_close($curl);

    if ($err) {
      echo "Curl Error #:" . $err;
      exit;
    } else {
      if($logStatus == 1){
      $logger->info('Push API response---');
      $logger->info(print_r(json_decode($response), true));
    }
      return json_decode($response);
    }
  }

  public function AddSecondaryShippingAddress($order,$apidata) {
    $token      = $this->tokenRequest()->token;
    $secondaryAddress  = $this->_datahelper->getSecondaryAddress($order,$apidata);
    $logStatus = $this->helper->isEnable();
    if($logStatus == 1){
      $writer = new \Zend\Log\Writer\Stream(BP . self::PUSH_API_ORDER_PAYMENT_SHIPPING_ADDRESS_CUSTOM_LOG);
      $logger = new \Zend\Log\Logger();
      $logger->addWriter($writer);
      $logger->info('order data in array--');
      
      $logger->info(print_r($secondaryAddress, true));
  }
    $postdata   = json_encode($secondaryAddress);
    $curl       = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_PORT => "86",
        CURLOPT_URL => self::API_PUSH_ADDITIONAL_ADDRESS_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $postdata,
        CURLOPT_HTTPHEADER => array(
              'Content-Type: application/json',
              'Authorization: Bearer '.$token
            ),
    ));

    $response = curl_exec($curl);
    $err      = curl_error($curl);

    curl_close($curl);

    if ($err) {
      echo "Curl Error #:" . $err;
      exit;
    } else {
        if($logStatus == 1){
        $logger->info('Push API response---');
        $logger->info(print_r(json_decode($response), true));
      }
      return json_decode($response);
    }
  } 

}
