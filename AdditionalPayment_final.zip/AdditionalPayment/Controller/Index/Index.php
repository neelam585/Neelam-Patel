<?php
/**
 * Third party payment
 * Created By: Rohit Chauhan
 * Author: RceptPharmacy
 * Purpose: Payment from mobile app using maganto router
 */

namespace Pharmacy\AdditionalPayment\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Pharmacy\AdditionalPayment\Helper\ApiRequest;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Directory\Model\RegionFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\Checkout\Model\Cart;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Customer\Model\Session;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\Data\AddressInterfaceFactory; 
use Magento\Customer\Api\AddressRepositoryInterface; 
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Request\Http;
use Magento\Framework\UrlInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Quote\Model\QuoteRepository;
use Pharmacy\AdditionalPayment\Helper\Data;
use Magento\CatalogInventory\Api\StockStateInterface;
use Psr\Log\LoggerInterface;

class Index extends Action
{   
    /**
     * @var \Pharmacy\AdditionalPayment\Helper\ApiRequest
     */
    protected $dataHelper;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Magento\Directory\Model\RegionFactory
     */
    protected $regionFactory;

    /**
     * @var \Magento\Customer\Api\Data\AddressInterfaceFactory
     */
    protected $dataAddressFactory;

    /**
     * @var \Magento\Customer\Api\AddressRepositoryInterface
     */
    protected $addressRepository;

    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $customerRepo;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_session;

    /**
     * @var \Magento\Checkout\Model\Session as CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $_coreSession;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $customerFactory;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;
    
    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    protected $resultFactory;

    /**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $_quoteRepo;

    /**
     * @var Pharmacy\AdditionalPayment\Helper\Data
     */
    protected $helperData;

    /**
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
    protected $stockState;

     /**
     * @var Magento\CatalogInventory\Api\StockStateInterface
     */
    protected $logger;

    /**
     * CONST variable for manage stock
     */
    const DEFAULT_STOCK_QTY = 9999;

    /**
     * CONST variable for manage stock
     */
    const ACTIVE_STATUS_VALUE = 1;

    /**
     * CONST variable for manage stock
     */
    const DEACTIVE_STATUS_VALUE = 0;

    /**
     * CONST variable for manage stock
     */
    const MAX_SALE_QTY = 9999;

    /**
     * Constructor params
     * 
     * @param Context $context
     * @param ApiRequest $dataHelper
     * @param ProductFactory $productFactory
     * @param ProductRepositoryInterface $productRepository
     * @param RegionFactory $regionFactory
     * @param AddressInterfaceFactory $dataAddressFactory
     * @param AddressRepositoryInterface $addressRepository
     * @param CustomerRepositoryInterface $customerRepo
     * @param Session $_session
     * @param CheckoutSession $checkoutSession
     * @param SessionManagerInterface $_coreSession
     * @param CustomerFactory $customerFactory
     * @param StoreManagerInterface $storeManager
     * @param FormKey $formKey
     * @param Cart $cart
     * @param Http $request
     * @param JsonFactory $resultJsonFactory
     * @param ResultFactory $resultFactory
     * @param QuoteRepository $quoteRepo
     * @param Data $_data
     * @param StockStateInterface $stockState
     * @param LoggerInterface $logger
     */
    public function __construct(
        Context $context,
        ApiRequest $dataHelper,
        ProductFactory $productFactory, 
        ProductRepositoryInterface $productRepository,
        RegionFactory $regionFactory,
        AddressInterfaceFactory $dataAddressFactory,
        AddressRepositoryInterface $addressRepository,
        CustomerRepositoryInterface $customerRepo,
        Session $_session, 
        CheckoutSession $checkoutSession,
        SessionManagerInterface $_coreSession,
        CustomerFactory $customerFactory,   
        StoreManagerInterface $storeManager,
        FormKey $formKey,
        Cart $cart,
        Http $request,
        JsonFactory $resultJsonFactory,
        ResultFactory $resultFactory,
        QuoteRepository $quoteRepo,
        Data $helperData,
        StockStateInterface $stockState,
        LoggerInterface $logger
        ) {
            $this->dataHelper           = $dataHelper;
            $this->productFactory       = $productFactory;
            $this->productRepository    = $productRepository;
            $this->regionFactory        = $regionFactory;
            $this->dataAddressFactory   = $dataAddressFactory;
            $this->addressRepository    = $addressRepository;
            $this->customerRepo         = $customerRepo;
            $this->_session             = $_session;
            $this->checkoutSession      = $checkoutSession;
            $this->_coreSession         = $_coreSession;
            $this->customerFactory      = $customerFactory;
            $this->storeManager         = $storeManager;
            $this->formKey              = $formKey;
            $this->cart                 = $cart;
            $this->request              = $request;
            $this->resultJsonFactory    = $resultJsonFactory;
            $this->resultFactory        = $resultFactory;
            $this->_quoteRepo           = $quoteRepo;
            $this->helperData          = $helperData;
            $this->stockState           = $stockState;
            $this->logger               = $logger;

            parent::__construct($context);
    }
    
    /**
     * Execute additional payment process from Mobile APP
     */
    public function execute()
    {  
        $ccid    = $this->request->getParam('account_id');
        $orderId = $this->request->getParam('order_id');

        if($ccid && $orderId) {
            try {
                /** Setting CCIC and OrderId into session */
				$this->setOrderIdCcidInSession($ccid, $orderId);

                /** Getting API data */
                $apiData = $this->apidata($ccid, $orderId);
                $this->_coreSession->start();
                // set Payment value in session
                $this->_coreSession->setCcId($ccid);
                $this->_coreSession->setOrderId($orderId);
                /*echo "<pre>";
                print_r($apiData); die();*/
               
                /** Create customer if new otherwise login with existing user*/
                $this->customerCreate($apiData);

                /**Truncate loggedin customer cart before adding products */
                $this->emptyCart();

                /**Setting API data into session */
                $this->setSession($apiData);

                /** Create product if new otherwise update price and addtocart */
                $cartStatus = $this->createProduct($apiData);

                /** Saving pharmacy location data into quote  */
                $this->savePharmacyAddressUrlHoursInQuote($apiData);
                
                /** Save CCID and OrderId into quote table */
                $this->saveDataInQuoteTable($ccid, $orderId);
                
                $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                $storeUrl = $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_WEB);
                $requestOrder = $this->helperData->getCustomerOrder();

                if($requestOrder == "" && $cartStatus > 0) {
                    $redirect->setUrl($storeUrl.'checkout');
                } else {
                    $redirect->setUrl($storeUrl.'sales/order/history');
                }
                
                return $redirect;
            } catch(\Exception $e) {
                $this->logger->info("exicution=".$e->getMessage());
                exit;
            }
        } else {
            try {
                $quoteItems = $this->checkoutSession->getQuote()->getAllVisibleItems();
                $response   = count($quoteItems);
                $result     = $this->resultJsonFactory->create();
                $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
                $resultJson->setData($response);

                return $resultJson;
            } catch (\Exception $e) {
                $this->logger->info("exicution else=".$e->getMessage());
            } 
        }
    }

    /**
     * Getting API data based on cc_id and order_id from DPE 
     * 
     * @var $ccid 
     * @var $orderId
     * 
     * @return Json||array
     */
    public function apidata($ccid, $orderId) {
        try {
            return $this->dataHelper->dataRequest($ccid, $orderId);
        } catch (\Exception $e) {
            $this->logger->info("API data= ".$e->getMessage());
            die('<h3>Somthing went wrong, Please try again after sometime.<h3>');
        } 
    }

    /**
     * Truncate active quote data
     * 
     * @return checkoutSession
     */
    public function emptyCart() {
        try {
            $_cart = $this->cart;
            $quoteItems = $_cart->getQuote()->getAllItems();
            foreach($quoteItems as $item)
            {
                $_cart->removeItem($item->getId())->save(); 
            }

        } catch (\Exception $e) {
            $this->logger->info("truncate cart= ".$e->getMessage());
        }
    }

    /**
     * Setting comapny logo into customer session
     * 
     * @var Json||array $apiData
     * @return session
     */
    public function setSession($apiData) {
        try {
            $this->_coreSession->start();
            // set Payment value in session
            $this->_coreSession->setPaymentValue('thirdparty');
            //set logo in session
            $this->_coreSession->setLog($apiData->logoPath);
        } catch (\Exception $e) {
            $this->logger->info("set session".$e->getMessage());
        }
    }

    /**
     * Setting cc_id and order_id into customer session
     * 
     * @var cc_id $ccid
     * @var order_id $orderNumber
     * 
     * @return session
     */
    public function setOrderIdCcidInSession($ccid, $orderNumber) {
         // set orderId in session
        $this->_coreSession->setCcId($ccid);
        $this->_coreSession->setOrderNumber($orderNumber);
    }

    /**
     * Create customer if new otherwise use exiting and login
     * 
     * @var Json||array $apiData
     * @return boolean
     */
    public function customerCreate($apiData) {
        try {
            //for custommer login start
            $customerEmail = $apiData->email;
            $customerData = $this->customerFactory->create()->getCollection()
                    ->addAttributeToSelect("*")
                    ->addAttributeToFilter("email", array("eq" => $customerEmail))
                    ->load();
            $customer_array = $customerData->getData();
            if(empty($customer_array))
            {
                /*echo "=====";
                die;*/
                $websiteId  = $this->storeManager->getWebsite()->getWebsiteId(); 
                $customer   = $this->customerFactory->create();
                $customer->setWebsiteId($websiteId);
                // Preparing data for new customer
                $customer->setEmail($customerEmail); 
                $customer->setFirstname(strtolower($apiData->firstname));
                $customer->setLastname(strtolower($apiData->lastname));
                $customer->setPassword($this->dataHelper::DEFAULT_CUST_PASS);
                // Save data
                $customer->save();
                $customerId = $customer->getId(); 
                //customer login
                $this->customerLogin($apiData);
                
                /* save address as customer */
                $address = $this->dataAddressFactory->create();
                $address->setFirstname(strtolower($apiData->firstname));
                $address->setLastname(strtolower($apiData->lastname));
                $address->setTelephone($apiData->telephone);
                $address->setCity(strtolower($apiData->city));
                $address->setPostcode($apiData->postcode);
                //get regionId 
                $region     = $this->regionFactory->create();
                $resionID   = $region->loadByCode($apiData->region_code, $apiData->country_id)->getId();
                $address->setRegionId($resionID);
                $address->setCountryId($apiData->country_id);
                $street     = array(strtolower($apiData->street), " ", " ");
                $address->setStreet($street);
                
                $address->setIsDefaultShipping(1);
                $address->setIsDefaultBilling(1);
                    
                $address->setCustomerId($customerId);
            
                $this->addressRepository->save($address);  
            
            } else { 
                // echo "else=";
                // die;
                //customer Login
                $this->customerLogin($apiData);
            }

        } catch (\Exception $e) {
            $this->logger->info("creating customer".$e->getMessage());
        }
    }

    /**
     * Customer login using api data and if already login reset session
     * and login with current user
     * 
     * @var Json||array $apiData
     * @return boolean
     */
    public function customerLogin($apiData) {
        try {
            $customerEmail      = $apiData->email;
            if(!$this->_session->isLoggedIn()) {
                $customerRepo   = $this->customerRepo->get($customerEmail);  
                $customer       = $this->customerFactory->create()->load($customerRepo->getId());  
                $this->_session->setCustomerAsLoggedIn($customer);
            } else {
                $loggedInEmail     = $this->_session->getCustomer()->getEmail();
                if($loggedInEmail != $customerEmail) {
                    //customer Logout
                    $this->_session->logout();
                    
                    $customerRepo  = $this->customerRepo->get($customerEmail);  
                    $customer      = $this->customerFactory->create()->load($customerRepo->getId());  
                    $this->_session->setCustomerAsLoggedIn($customer);
                } else {
                    return true;
                }
            }

            return true;
        } catch (\Exception $e) {
            $this->logger->info("customer login".$e->getMessage());
        }
    }

    /**
     * Create product if not exist and addtocart
     * 
     * @var json||array
     * @return int
     */
    public function createProduct($apiData) {
        
        if(count($apiData->products)> 0 && ($apiData->products) != null){
        foreach($apiData->products as $_data) {  
            try {
                $productFactory = $this->productFactory->create();
                $_product       = $productFactory->setStoreId(1)->load($productFactory->getIdBySku($_data->sku));
                if($_product->getId()){
                    $this->addExistingProductToCart($_data, $_product, $_product->getId());
                } else {
                    $this->createProductAndAddToCart($_data);
                }
            } catch (\Exception $e) {
                $this->logger->info("creating products ".$e->getMessage());
            }

            $cartId = $this->cart->getQuote()->getId();
            $quote  = $this->_quoteRepo->getActive($cartId);
            $cartitems = $this->cart->getQuote()->getAllItems();
            
            $this->_quoteRepo->save($quote);
            $quote->collectTotals();

        }
    }

        $quoteItems = $this->cart->getQuote()->getAllVisibleItems();
        $response   = count($quoteItems);

        return $response;
    }

    /**
     * Save ccid and orderid in to active quote
     * 
     * @var cc_id $ccid
     * @var order_id $orderNumber
     * 
     * @return boolean
     */
    public function saveDataInQuoteTable($ccid, $orderNumber) {
        try {
            $quoteId = $this->checkoutSession->getQuote()->getId();
            if($quoteId) {
                $quotemodel     = $this->_quoteRepo->get($quoteId);
                $quotemodel     = $quotemodel->setData('account_id', $orderNumber);
                $quotemodel     = $quotemodel->setData('cc_id', $ccid);
                $quotemodel->save();
            }
        } catch(\Exception $e) {
            $this->logger->info("saveDataInQuoteTable ".$e->getMessage());
        }
    }

    /**
     * Save PharmacyAddress, Working Hours and Map Url in to active quote
     * 
     * @var Json||array $apiData
     * @return boolean
     * 
     */
    public function savePharmacyAddressUrlHoursInQuote($apiData) {
        $pharmacyAddress = $apiData->pharmacyAddress;
        $mapUrl          = $apiData->locationMapURL;  
        $pharmacyHours   = $apiData->pharmacyHours;
        $pharmacyName    = $apiData->pharmacyName;
        $apiDate         = str_replace('-', '/', $apiData->deliveryDate);  
        //$data= "08-26-2021";
        //$date = str_replace('-', '/', $var);
        $deliveryDate    = date("Y-m-d", strtotime($apiDate));

        //$data = "07/12/2010";
/*$your_date = date("Y-m-d", strtotime($data));
        echo $your_date;exit;*/
        //echo $deliveryDate.'sssss';exit;
        $quoteId         = $this->checkoutSession->getQuote()->getId();
         
        if($quoteId) {
            $quotemodel = $this->_quoteRepo->get($quoteId);
            $quotemodel = $quotemodel->setData('pharmacy_address', $pharmacyAddress);
            $quotemodel = $quotemodel->setData('location_map_url', $mapUrl);
            $quotemodel = $quotemodel->setData('pharmacy_hours', $pharmacyHours); 
            $quotemodel = $quotemodel->setData('pharmacy_name', $pharmacyName); 
            $quotemodel = $quotemodel->setData('delivery_date', $deliveryDate);  
            $quotemodel->save();
        }
    }

    /**
     * Adding existing products to cart
     * 
     * @param Json||array $_data
     * @param object $_product
     * @param int $productId
     * 
     * @return boolean
     * 
     */
    public function addExistingProductToCart($_data, $_product, $productId) { 
        try {
            $productQty     = $this->stockState->getStockQty($productId, 1);
            $updateStatus   = 0;
            if($productQty < $_data->qty) {
                $_product->setStockData(['qty' => self::DEFAULT_STOCK_QTY, 'is_in_stock' => 1]);
                $_product->setQuantityAndStockStatus(['qty' => self::DEFAULT_STOCK_QTY, 'is_in_stock' => 1]);
                $updateStatus = 1;
            }
            if($_data->price < $_product->getPrice() || $_data->price > $_product->getPrice()) {
                $_product->setPrice($_data->price);
                $updateStatus = 1;
            }
            if($updateStatus == 1) {
                $_product->save();
            }

            $params = array(
                'form_key' => $this->formKey->getFormKey(),
                'product' => $_product->getId(), 
                'qty'   => $_data->qty
            );  
          
            $this->cart->addProduct($_product, $params);
            $this->cart->save();

        } catch(\Exception $e) {
            $this->logger->info("addExistingProductToCart ".$e->getMessage());
            exit;
        }
    }

     /**
     * create product and add to cart
     * 
     * @param Json||array $_data
     * 
     * @return boolean
     * 
     */
    public function createProductAndAddToCart($_data) {
        try {
            $productFactory = $this->productFactory->create();
            $productFactory->setSku($_data->sku);
            $productFactory->setName($_data->sku); // set your Product Name of Product
            $productFactory->setAttributeSetId(4); // set attribute id
            $productFactory->setStatus(self::ACTIVE_STATUS_VALUE); // status enabled/disabled 1/0
            $productFactory->setWeight(''); // set weight of product
            $productFactory->setVisibility(1); // visibility of product (Not Visible Individually (1) / Catalog (2)/ Search (3)/ Catalog, Search(4))
            $productFactory->setWebsiteIds([self::ACTIVE_STATUS_VALUE]);
            $productFactory->setTaxClassId(self::DEACTIVE_STATUS_VALUE); // Tax class ID
            $productFactory->setTypeId('simple'); // type of product (simple/virtual/downloadable/configurable)
            $productFactory->setPrice($_data->price); // set price of product
            $productFactory->setStockData(
                array(
                    'use_config_manage_stock' => self::DEACTIVE_STATUS_VALUE,
                    'manage_stock' => self::ACTIVE_STATUS_VALUE,
                    'is_in_stock' => self::ACTIVE_STATUS_VALUE,
                    'min_sale_qty' => self::ACTIVE_STATUS_VALUE,
                    'max_sale_qty' => self::MAX_SALE_QTY,
                    'qty' => self::DEFAULT_STOCK_QTY
                )
            );
            $productFactory->setPrescription(5);
            $productFactory->save();
            $params = array(
                'form_key'  => $this->formKey->getFormKey(),
                'product'   => $productFactory->getId(), 
                'qty'       => $_data->qty
            );                   
            $this->cart->addProduct($productFactory, $params);
            $this->cart->save();

            return true;
        } catch(\Exception $e) {
            $this->logger->info("createProductAndAddToCart ".$e->getMessage());
        }
    }
}
