<?php
namespace Pharmacy\AdditionalPayment\Controller\Index; 

class Errormessage extends \Magento\Framework\App\Action\Action
{ 
	protected $dataHelper;
	protected $_pageFactory;
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Pharmacy\AdditionalPayment\Helper\Data $dataHelper,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->dataHelper           = $dataHelper;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
    //echo "AAAAAAAAA";exit;
/*
     $push_address =[
        "Ccid"   => "4931021-1159",
        'secondaryShippingAddresses' =>[
        	array(
         'CustomerEmail' => '4931021-1159@receptrx.com',
    'FirstName'  => 'CATHERINE',
    'LastName' => 'MICHAEL',
    'Street' =>"1808 MINOR AVE UNIT #1202",
    'City' =>"SEATTLE",
    'StateProvince' =>"WA",
    'Country' =>"US",
    'Pincode' =>"98101",
    'PhoneNumber' =>"425-765-9207",
    'CreatedDate' =>"2022-02-08T09:17:51.995Z"
)
        ]
    ];
    $postdata=json_encode($push_address);

$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_PORT => "86",
  CURLOPT_URL => "https://stagingtp.recepthealthcare.com:86/api/OrderPayment/AddSecondaryShippingAddress/",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "POST",
  CURLOPT_POSTFIELDS => $postdata,
  CURLOPT_HTTPHEADER => array(
    "authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjE2NDQzNTQ2OTYsImlzcyI6Imh0dHBzOi8vbG9jYWxob3N0OjQ0MzUzLyIsImF1ZCI6Imh0dHBzOi8vbG9jYWxob3N0OjQ0MzUzLyJ9._o984NivpqWCZxBxiI_mcZb740xxfK717FjYjsJhs0s",
    "cache-control: no-cache",
    "content-type: application/json",
    "postman-token: 4dd718f2-1e65-b776-d1f9-6fa55c752816"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  echo $response;
}*/
	  //echo "hhhhhhhh"; 
	  //  $customerAddress = $this->dataHelper->getSecondaryAddress();
		return $this->_pageFactory->create(); 

	}
}
