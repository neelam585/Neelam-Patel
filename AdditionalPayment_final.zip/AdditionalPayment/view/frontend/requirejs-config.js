var config = {
config: {
            mixins: {
                'Magento_Checkout/js/view/shipping-information': {
                    'Pharmacy_AdditionalPayment/js/view/shipping-information': true
                }
            }
        }
    };