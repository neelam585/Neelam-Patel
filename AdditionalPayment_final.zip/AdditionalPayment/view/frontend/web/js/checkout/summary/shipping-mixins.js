/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define([
    'jquery',
    'ko',
    'Magento_Checkout/js/model/quote',
    'mage/url'
], function ($, ko, quote, url) {
    'use strict';

    quote.shippingMethod.subscribe(function () {
            linkUrl = url.build('additionalPayment/index/index?duplicate=1');
            $('body').trigger('processStart');
            $.ajax({
                url : linkUrl,
                type : 'GET',
                data: {
                    format: 'json'
                },
                dataType:'json',
                success : function(data) { 
                    var datahtml = "<div class='message'><a href='"+data+"'>View Report</a></div>";           
                    $('#checkout-shipping-method-load').after(datahtml);
                    $('body').trigger('processStop');
                },
                error : function(request,error)
                {
                    
                    $('body').trigger('processStop');
                }
            });
    });

    return function (target) {
        return target.extend({});
    }
});