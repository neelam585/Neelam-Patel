<?php 
/**
 * PUSH API to send order data to DPE database after place order .
 */

namespace Pharmacy\AdditionalPayment\Observer;

use Pharmacy\AdditionalPayment\Helper\Data;
use Pharmacy\AdditionalPayment\Helper\ApiRequest;

class OrderDataObserver implements \Magento\Framework\Event\ObserverInterface
{   
    /**
     * @var Data
     */
    protected $_datahelper;

    /**
     * @var ApiRequest
     */
    protected $_apirequesthelper;

    /**
     * Construct Params
     * 
     * @param Data          $dataHelper
     * @param ApiRequest    $ApiRequestHelper
     */
    public function __construct(
        Data $dataHelper,
        ApiRequest $ApiRequestHelper
    ) {
        $this->_datahelper          = $dataHelper;
        $this->_apirequesthelper    = $ApiRequestHelper;
    }

    /**
     * @param Observer $observer
     * @return $this;
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/push_api_response.log');
        $logger = new \Zend\Log\Logger();
        $logger->addWriter($writer);
        $logger->info('start pusshing');
        
        $order_ids      = $observer->getEvent()->getOrderIds();
        $order_id       = $order_ids[0];
        $apiResponse    = $this->_apirequesthelper->OrderPaymentInfodata($order_id);

        $logger->info(print_r($apiResponse, true));
    }
}
