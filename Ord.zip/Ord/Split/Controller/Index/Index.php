<?php
namespace Ord\Split\Controller\Index;

class Index extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;
	protected $helper;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Ord\Split\Helper\Data $helper,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->helper = $helper;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{
		//echo $this->helper->isActive();
		echo $this->helper->getAttributes();
		//return $this->_pageFactory->create();
	}
}