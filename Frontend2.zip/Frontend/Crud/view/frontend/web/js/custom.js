 require(
        [
            'jquery',
            'Magento_Ui/js/modal/modal',
             'mage/url'
        ],
        function($, modal, urlBuilder) {
            var options = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                title: 'Pop-up title',
                buttons: [{
                    text: $.mage.__('Close'),
                    class: 'modal-close',
                    click: function (){
                        this.closeModal();
                    }
                }]
            };

            modal(options, $('#modal-content'));
            $("#modal-btn").on('click',function(){
                $("#modal-content").modal("openModal");
            });
            $(document).ready(function($) {
            $("#model-button").click(function(e){
                    e.preventDefault();
            var saveUrl = urlBuilder.build('crud/index/save');
            var file = document.getElementById('image').files[0];
            var title = $('#title').val();
            var val = $("input[type='radio']:checked").val(); alert(val);
            var form;
            if (typeof file != 'undefined') {
                form = new FormData();
                form.append('form_key',window.FORM_KEY);
                form.append('image', file);
                form.append('title', title);
                form.append('status', val);
            }
            console.log(form);
           
            var image_file = $('#image').val();
            
  
            $.ajax(
                    {
                        url: saveUrl,
                        mimeTypes: 'multipart/form-data',
                        data:form,
                        type: 'POST',
                        cache: false,
                        contentType: false,  //this is must required
                        processData: false, //this is must required
                        
                        success: function (data) {
                            $("#modal-content").modal("closeModal");
                        }
                    });
                });    
                //delete record
         $('body').on('click', '.delete', function() {
            //alert('sssssss');
                var deleteUrl = urlBuilder.build('crud/index/delete');
                //var id = $(this).data('id');
                var id = $(this).attr('id');
                debugger;
                alert(id);
                $.ajax({
                    type: "POST",
                    url: deleteUrl,
                    data: {
                        id: id
                    },
                    dataType: 'json',
                    success: function(res) {
                      alert('aaaaaaa');
                        window.location.reload();
                    }
                });
            
        });
                
        });
            
            
    });
