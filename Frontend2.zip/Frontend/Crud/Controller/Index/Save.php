<?php
 
namespace Frontend\Crud\Controller\Index;
use Magento\Framework\App\Filesystem\DirectoryList;
 
class Save extends \Magento\Framework\App\Action\Action
{
     protected $_pageFactory;
     protected $_postFactory;
     private $filesystem;
     private $fileUploaderFactory;
 
     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
          \Magento\Framework\Filesystem $filesystem,
          \Banner\Grid\Model\PostFactory $postFactory
          
     ){
          $this->_pageFactory = $pageFactory;
          $this->_postFactory = $postFactory;
          $this->fileUploaderFactory = $fileUploaderFactory;
          $this->filesystem = $filesystem;

          return parent::__construct($context);
     }
 
     public function execute()
     {
          if ($this->getRequest()->isPost()) {
          $post = $this->getRequest()->getPostValue();
          //print_r($post);die;
          /*$fileName   = $_FILES['image']['name'];
          var_dump($fileName);die;*/
         
         $fileData = $this->getRequest()->getFiles('image');
         //print_r($fileData);die;
         $fileName = $fileData['name'];

         $allowed_file_extension = ["png", "jpg", "jpeg", "gif", "pdf"];
         $file_extension = pathinfo($fileName, PATHINFO_EXTENSION);   
         if(in_array($file_extension, $allowed_file_extension)) {
         $mediaDir = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
         $mediapath = $this->_mediaBaseDirectory = rtrim($mediaDir, '/');
         //var_dump($mediapath);die;
         $uploader = $this->fileUploaderFactory->create(['fileId' => 'image']);
                            $uploader->setAllowedExtensions($allowed_file_extension);
                            $uploader->setAllowRenameFiles(true);
                            $path   = $mediapath . '/image/';
                            $result = $uploader->save($path);
        
          }
          $model = $this->_postFactory->create();

          $model->setData('title',$post['title']);

          $model->setData('image',$fileData['name']);
          $model->setData('status',$post['status']);
          $model->save();

          return $this->_redirect('crud/index/index');
          }
     }
}
