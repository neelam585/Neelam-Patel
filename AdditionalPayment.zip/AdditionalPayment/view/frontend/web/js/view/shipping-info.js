;define([
    'uiComponent',
    'ko',
    'Magento_Checkout/js/model/quote'

], function (Component, ko, quote) {
    'use strict';

    return Component.extend({
        defaults: {
            template: 'Pharmacy_AdditionalPayment/shipping-info'
        },

        initObservable: function () {
            var self = this._super();
           
            this.showCustomShippingAddr = ko.computed(function() {
                var method = quote.shippingMethod();

                if(method && method['carrier_code'] !== undefined) {
                    if(method['carrier_code'] === 'custom') {
                        jQuery('.addcssforlocation').addClass('custom-locatoin-select');
                        jQuery('.delivery-custom').hide();
                        return true;
                    } else {
                        jQuery('.addcssforlocation').removeClass('custom-locatoin-select');
                        jQuery('.delivery-custom').show();
                    }
                }

                return false;

            }, this);

            return this;
        }
    });
});
