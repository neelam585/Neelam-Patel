define([
    'uiComponent',
    'ko',
    'jquery'
], function (Component, ko, $,) {
    'use strict';
    return Component.extend({
    });
});