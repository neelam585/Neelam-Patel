<?php
/**
 * Data helper
 */
namespace Pharmacy\AdditionalPayment\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Api\OrderRepositoryInterface;
use Magento\Framework\UrlInterface; 

class Data extends AbstractHelper
{
    /**
     * @var UrlInterface
     */ 
    protected $urlInterface;
   
   /**
     * @var SessionManagerInterface
    **/ 
    protected $_coreSession;

    /**
     * @var CollectionFactory
     */ 
    protected $orderCollectionFactory;

   /**
    * @var StoreManagerInterface
    */ 
	protected $storeManager;

    /**
     * @var \Magento\Checkout\Model\Session as CheckoutSession
     */
    protected $checkoutSession;

    /**
	* @var StoreManagerInterface
	*/ 
    protected $quoteRepository;

    /**
   * @var StoreManagerInterface
   */ 
     protected $_orderData;
  
    /**
     * Constructor params
     * 
     * @param CollectionFactory $orderCollectionFactory
     * @param SessionManagerInterface $_coreSession
     * @param SessionManagerInterface $storeManager
     * @param CheckoutSession $checkoutSession
     * @param QuoteRepository $quoteRepository
     * @param OrderRepositoryInterface $orderData
     */
  public function __construct(
        UrlInterface $urlInterface,
        CollectionFactory $orderCollectionFactory,
        SessionManagerInterface $_coreSession,
        StoreManagerInterface $storeManager,
        CheckoutSession $checkoutSession,
        QuoteRepository $quoteRepository,
        OrderRepositoryInterface $orderData
    ) {
        $this->urlInterface             = $urlInterface;    
        $this->orderCollectionFactory   = $orderCollectionFactory;
        $this->_coreSession             = $_coreSession; 
        $this->storeManager             = $storeManager;
        $this->checkoutSession          = $checkoutSession;
        $this->quoteRepository          = $quoteRepository;
        $this->_orderData               = $orderData;   
    }

    /**
     * get payment value from session
     */
    public function getSessionValue()
    {
        return $this->_coreSession->getPaymentValue();
    }

    /**
     * get third party logo url from session
     */
    public function getLogoSessionValue()
    {    
        return $this->_coreSession->getLog();
    }

    /**
     * unset logo session
     */
    public function unsetLogoSession()
    {    
        return $this->_coreSession->unsLog();
    }

    /**
     * unset third party payment session
     */
    public function unsetSessionValue()
    {    
        //get logo from session
        return $this->_coreSession->unsPaymentValue();
    }
    /**
     * get orderId and ccid from session
     */
    public function getOrderIdSessionValue()
    {    
        return $this->_coreSession->getOrderNumber();
    }
    public function getCcIdSessionValue()
    {    
        return $this->_coreSession->getCcId();
    }

    /**
     * Getting loggedin customer order from API
     * 
     * @return string||Null
     */
    public function getCustomerOrder() { 
        $orderId= $this->getOrderIdSessionValue(); 
        $ccId   = $this->getCcIdSessionValue();
    $result = "";   
        $customerOrder  = $this->orderCollectionFactory->create()
                            ->addFieldToFilter('account_id', $orderId)
                            ->addFieldToFilter('cc_id', $ccId);

        if($customerOrder->getTotalCount() > 0) {
            $orderId    = $customerOrder->getFirstItem()->getEntityId();
            $storeUrl   = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
            $result     = $storeUrl.'sales/order/print/order_id/'.$orderId;
        }
    
    return $result;
    }
	
	/**
     * Getting Order data for PUSH API
     * 
	 * @param $orderId
	 *
     * @return array
     */
    public function getOrderData($orderId){
        $order      = $this->_orderData->get($orderId);
        $orderItems = $order->getAllItems();
        //get deliveryDate 
           //$deliveryDate =  $order->getDeliveryDate();
        $date        = str_replace('-', '/', $order->getDeliveryDate());
        $deliveryDate= date("m-d-Y", strtotime($date));
        //echo $this->deliveryDate().'nnnnnnn';exit;
        $orderPaymentItem = [];
       
        foreach ($orderItems as $item) {
           $orderPaymentItem[] = [
                        "Sku"       => $item->getSku(),
                        "Price"     => $item->getPrice(),
                        "Qty"       => (int)$item->getQtyOrdered(),
                        "Subtotal"  => $item-> getRowTotal()
           ];
        }
        $street = implode(" ,", $order->getShippingAddress()->getStreet());
        $paymentStatus = $order->getPayment()->getLastTransId();
        $status = "";
        if($paymentStatus) {
            $paymentStatus = explode("-",$paymentStatus);
            $status = $paymentStatus[0];
        }
        $orderData   =  [
                "Ccid"                          => $order->getCcId(),
                "OrderNo"                       => $order->getAccountId(),
                "TransactionStatus"             => $status,
                "TotalItemQty"                  => (int)$order->getTotalQtyOrdered(),
                "ShippingCarrierCode"           => $order->getShippingDescription(),
                "ShippingCost"                  => $order->getBaseShippingAmount(),
                "PaymentMethodCode"             => $order->getPayment()->getMethod(),
                "Subtotal"                      => $order->getSubtotal(),
                "GrandTotal"                    => $order->getGrandTotal(),
                "PaymentProcessorResponse"      => $order->getPayment()->getCcCidStatus(),
                "CreditCardNumber"              => $order->getPayment()->getCcLast4(),
                "TransactionDatetime"           => $order->getCreatedAt(),
                "orderPaymentItem"              => $orderPaymentItem,
                "OrderPaymentShippingAddress"   => [
                                    "CustomerEmail" => $order->getCustomerEmail(),
                                    "FirstName"     => $order->getCustomerFirstname(),
                                    "LastName"      => $order->getCustomerLastname(),
                                    "Street"        => $street,
                                    "City"          => $order->getShippingAddress()->getCity(),
                                    "StateProvince" => $order->getShippingAddress()->getRegion(),
                                    "Country"       => $order->getShippingAddress()->getCountryId(),
                                    "Pincode"       => $order->getShippingAddress()->getPostcode(),
                                    "PhoneNumber"   => $order->getShippingAddress()->getTelephone(),
                                    "DeliveryDate"  => $deliveryDate
                                ],
               "PaymentMethod"=>[
                        "PaymentType"=> $order->getPayment()->getAdditionalInformation('method_title')
                ]
            ];
           
           return $orderData;
       }
    
    /**
     * Getting Phamacy Address from API
     * 
     * @return string||Null
     */
    public function getPharmacyAddress(){
        $quoteId  = $this->checkoutSession->getQuote()->getId();
        $quote    = $this->quoteRepository->get($quoteId);
        
        if($quote->getPharmacyAddress()) {
            return $quote->getPharmacyAddress();
        } else {
            return null;
        }
    }

    /**
     * Getting Phamacy Location Map from API
     * 
     * @return string||Null
     */
    public function getLocationMapUrl() {
       $quoteId = $this->checkoutSession->getQuote()->getId();
       $quote   = $this->quoteRepository->get($quoteId);
       $urlMap  = $quote->getLocationMapUrl();
       $storeName  = $this->getPharmacyName();

       if($urlMap) {
            $urlMap     = explode("=", $urlMap);
            $map_url    = $urlMap[0];
            $url2       = rawurldecode($storeName.' '.$urlMap[1]);
            $finalUrl   = $map_url.'='.$url2;
   
            return "<a href='$finalUrl' class='button action continue primary' target='_blank'>Location Map </a>";
        }
        
        return null;
    }
   
    /**
     * Getting Phamacy working hours from API
     * 
     * @return string||Null
     */
    public function getPharmacyHours() {
       $quoteId = $this->checkoutSession->getQuote()->getId();
       $quote   = $this->quoteRepository->get($quoteId);
       
       if($quote->getPharmacyHours()) {
            return $quote->getPharmacyHours();
        } else {
            return null;
        }
    }

    /**
     * Getting Phamacy working hours from API
     * 
     * @return string||Null
     */
    public function getPharmacyName() {
        $quoteId = $this->checkoutSession->getQuote()->getId();
        $quote   = $this->quoteRepository->get($quoteId);
        
        if($quote->getPharmacyName()) {
             return $quote->getPharmacyName();
        } else {
            return null;
        }
    }

	/**
     * Getting current URL
     * 
     * @return string
     */
    public function getCurrentUrl(){
       return $this->urlInterface->getCurrentUrl();
    }  
    /**
     * Getting Delivery Date from API
     * 
     * @return string||Null
     */
    public function deliveryDate(){
        
        $quoteId = $this->checkoutSession->getQuote()->getId();
        $quote   = $this->quoteRepository->get($quoteId);
        
        if($quote->getDeliveryDate()) {
            $date = str_replace('-', '/', $quote->getDeliveryDate());
            $deliveryDate= date("m-d-Y", strtotime($date));

             return $deliveryDate;
        } else {
            return null;
        }
    }
}
