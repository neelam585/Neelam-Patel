<?php
namespace Pharmacy\AdditionalPayment\Helper;
 
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use Magento\Framework\HTTP\Client\Curl;
use Pharmacy\AdditionalPayment\Helper\Data;
 
class ApiRequest extends AbstractHelper
{
 
  /**
  * @var Curl
  */
  protected $curl;

  /**
  * @var Helper
  */
  protected $_datahelper;

  /**
   * Constant variable
   */
  const DEFAULT_CUST_PASS = "chetu@123";

  /**
   * Constant variable
   */
  const API_AUTH_USER = "Recept";

  /**
   * Constant variable
   */
  const API_AUTH_PASS = "Welcome123!";

   /**
   * Constant variable
   */
  const API_TOKEN_URL = "https://stagingtp.recepthealthcare.com:86/Login/";

   /**
   * Constant variable
   */
  const API_REQUEST_DATA_URL = "https://stagingtp.recepthealthcare.com:86/api/CustomerOrderDetails";

  /**
   * Constant variable
   */
  const API_PUSH_DATA_URL = "https://stagingtp.recepthealthcare.com:86/api/OrderPayment/OrderPaymentInfo";
   
  public function __construct(
    Context $context,
    Curl $curl,
    Data $dataHelper
  ) {
    parent::__construct($context);
    $this->curl         = $curl;
    $this->_datahelper  = $dataHelper;
  }
 
public function tokenRequest() {
      $loginData = json_encode([
        "UserName"  => self::API_AUTH_USER,
        "Password" =>  self::API_AUTH_PASS
      ]);
      $curl = curl_init();

      curl_setopt_array($curl, array(
      CURLOPT_URL => self::API_TOKEN_URL,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => $loginData,
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json'
      ),
    ));

    $response = curl_exec($curl);
   
    if (curl_errno($curl)) {
        echo "Error => ".$error_msg = curl_error($curl);
        exit;
    }

    curl_close($curl);

    return json_decode($response);
  }   

  public function dataRequest($ccid, $orderId) {
      $token = $this->tokenRequest()->token;
      $data = json_encode([
        "CCID"  => $ccid,
        "Order" => $orderId
      ]);
      $curl = curl_init();

      curl_setopt_array($curl, array(
      CURLOPT_URL => self::API_REQUEST_DATA_URL,
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => '',
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 0,
      CURLOPT_FOLLOWLOCATION => true,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => 'POST',
      CURLOPT_POSTFIELDS => $data,
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json',
        'Authorization: Bearer '.$token
      ),
    ));

    $response = curl_exec($curl);
    curl_close($curl);

    return json_decode($response);
  }

  public function OrderPaymentInfodata($orderId) {
    $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/push_api_request_response.log');
    $logger = new \Zend\Log\Logger();
    $logger->addWriter($writer);
    $logger->info('order data in array--');
    $token      = $this->tokenRequest()->token;
    $orderData  = $this->_datahelper->getOrderData($orderId);
    $logger->info(print_r($orderData, true));
    $postdata   = json_encode($orderData);
    $curl       = curl_init();

    curl_setopt_array($curl, array(
        CURLOPT_PORT => "86",
        CURLOPT_URL => self::API_PUSH_DATA_URL,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => $postdata,
        CURLOPT_HTTPHEADER => array(
              'Content-Type: application/json',
              'Authorization: Bearer '.$token
            ),
    ));

    $response = curl_exec($curl);
    $err      = curl_error($curl);

    curl_close($curl);

    if ($err) {
      echo "Curl Error #:" . $err;
      exit;
    } else {
      $logger->info('Push API response---');
      $logger->info(print_r(json_decode($response), true));
      return json_decode($response);
    }
  } 

}
