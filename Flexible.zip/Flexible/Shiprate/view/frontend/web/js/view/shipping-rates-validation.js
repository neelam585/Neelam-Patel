define([
    'uiComponent',
    'Magento_Checkout/js/model/shipping-rates-validator',
    'Magento_Checkout/js/model/shipping-rates-validation-rules',
    'Flexible_Shiprate/js/model/shipping-rates-validator',
    'Flexible_Shiprate/js/model/shipping-rates-validation-rules'
], function (Component,
             defaultShippingRatesValidator,
             defaultShippingRatesValidationRules,
             customShippingRatesValidator,
             customShippingRatesValidationRules) {
    'use strict';
 
    defaultShippingRatesValidator.registerValidator('custom', customShippingRatesValidator);
    defaultShippingRatesValidationRules.registerRules('custom', customShippingRatesValidationRules);
 
    return Component;
});
