<?php
/**
 * Copyright ©  All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);

namespace Banner\Slider\Api\Data;

interface BannerInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{

    const STATUS = 'status';
    const BANNER_ID = 'banner_id';
    const IMAGE = 'image';
    const TITLE = 'title';

    /**
     * Get banner_id
     * @return string|null
     */
    public function getBannerId();

    /**
     * Set banner_id
     * @param string $bannerId
     * @return \Banner\Slider\Api\Data\BannerInterface
     */
    public function setBannerId($bannerId);

    /**
     * Get title
     * @return string|null
     */
    public function getTitle();

    /**
     * Set title
     * @param string $title
     * @return \Banner\Slider\Api\Data\BannerInterface
     */
    public function setTitle($title);

    /**
     * Retrieve existing extension attributes object or create a new one.
     * @return \Banner\Slider\Api\Data\BannerExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     * @param \Banner\Slider\Api\Data\BannerExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \Banner\Slider\Api\Data\BannerExtensionInterface $extensionAttributes
    );

    /**
     * Get image
     * @return string|null
     */
    public function getImage();

    /**
     * Set image
     * @param string $image
     * @return \Banner\Slider\Api\Data\BannerInterface
     */
    public function setImage($image);

    /**
     * Get status
     * @return string|null
     */
    public function getStatus();

    /**
     * Set status
     * @param string $status
     * @return \Banner\Slider\Api\Data\BannerInterface
     */
    public function setStatus($status);
}

