<?php

namespace Pharmacy\Validation\Plugin\Block\Checkout;

use Magento\Checkout\Block\Checkout\AttributeMerger;

class PhonePlugin
{
    /**
     * @param AttributeMerger $subject
     * @param $result
     * @return mixed
     */
    public function afterMerge(AttributeMerger $subject, $result)
    {
        $result['telephone']['validation'] = [
            'min_text_length' => 12,
            'max_text_length' => 12
        ];
		
        return $result;
    }
}