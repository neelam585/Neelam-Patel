<?php
/**
 * AdditionalPayment Doc Comment
 *
 * PHP version 7.3.18
 *
 * @category  Safeware
 * @package   Safeware_AdditionalPayment
 * @author    Rceipt Pharmacy <rceiptPharmacy@gmail.com>
 * @copyright 2021-2022 Squiz Pty Ltd (ABN 77 084 670 600)
 * @license   https://www.safeware.com/ Safeware License
 * @link      https://stagingpayment.recepthealthcare.com
 */
 
    namespace Pharmacy\AdditionalPayment\Model\Carrier;
     
    use Magento\Quote\Model\Quote\Address\RateRequest;
    use Magento\Shipping\Model\Rate\Result;
    use Magento\Shipping\Model\Carrier\AbstractCarrier;
    use Magento\Shipping\Model\Carrier\CarrierInterface;
    use Magento\Framework\App\Config\ScopeConfigInterface;
    use Magento\Quote\Model\Quote\Address\RateResult\ErrorFactory;
    use Psr\Log\LoggerInterface;
    use Magento\Shipping\Model\Rate\ResultFactory;
    use Magento\Quote\Model\Quote\Address\RateResult\MethodFactory;
    use Magento\Framework\Session\SessionManagerInterface;
 
class Custom extends AbstractCarrier implements CarrierInterface
{
    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $coreSession;

    protected $_code = 'custom';
    /**
     * @var \Magento\Shipping\Model\Rate\ResultFactory
     */

    protected $rateResultFactory;
    /**
     * @var \Magento\Quote\Model\Quote\Address\RateResult\MethodFactory
     */

    protected $rateMethodFactory;
    /**
     * Constructor params
     * 
     * @param SessionManagerInterface $coreSession
     * @param ScopeConfigInterface    $scopeConfig
     * @param ErrorFactory            $rateErrorFactory
     * @param ResultFactory           $rateResultFactory
     * @param MethodFactory           $rateMethodFactory
     */

    public function __construct(
        SessionManagerInterface $coreSession,
        ScopeConfigInterface $scopeConfig,
        ErrorFactory $rateErrorFactory,
        LoggerInterface $logger,
        ResultFactory $rateResultFactory,
        MethodFactory $rateMethodFactory,
        array $data = []
    ) {
        $this->coreSession = $coreSession;
        $this->rateResultFactory = $rateResultFactory;
        $this->rateMethodFactory = $rateMethodFactory;
        parent::__construct($scopeConfig, $rateErrorFactory, $logger, $data);
    }
    /**
     * create custom shipping method
     */

    public function getAllowedMethods()
    {
        return ['custom' => $this->getConfigData('name')];
    }
     
    public function collectRates(RateRequest $request)
    { 
        if (!$this->getConfigFlag('active')) {
            return false;
        }
        $session = $this->coreSession->getPaymentValue();
        if($session == 'thirdparty') {
       /**
        * 
        *
        * @var \Magento\Shipping\Model\Rate\Result $result 
        */
            $result = $this->rateResultFactory->create();
     
       /**
        * 
        *
        * @var \Magento\Quote\Model\Quote\Address\RateResult\Method $method 
        */
            $method = $this->rateMethodFactory->create();
            
            $method->setCarrier('custom');
            $method->setCarrierTitle($this->getConfigData('title'));
     
            $method->setMethod('custom');
            $method->setMethodTitle($this->getConfigData('name'));
     
            /*you can fetch shipping price from different sources over some APIs, we used price from config.xml - xml node price*/
            $amount = $this->getConfigData('price');
            $shippingPrice = $this->getFinalPriceWithHandlingFee($amount);
            $method->setPrice($shippingPrice);
            $method->setCost($amount);
     
            $result->append($method);
     
            return $result;
        }
    }
}
