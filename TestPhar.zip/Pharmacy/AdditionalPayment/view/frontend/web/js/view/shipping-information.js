/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

define(
    [
    'jquery',
    'uiComponent',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/model/step-navigator',
    'Magento_Checkout/js/model/sidebar'
    ], function ($, Component, quote, stepNavigator, sidebarModel) {
        'use strict';

        var mixin = {
            /**
             * @return {Boolean}
             */
            isVisible: function () { 
                var shippingMethod = quote.shippingMethod();
                return !quote.isVirtual() && stepNavigator.isProcessed('shipping') && (shippingMethod['carrier_code'] !== 'custom');
            },
        };

        /**
         * Override default getShippingMethodTitle
         */
        return function (OriginShipping) {
            return OriginShipping.extend(mixin);
        };

    }
);
