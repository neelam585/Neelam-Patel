<?php 
/**
 * AdditionalPayment Doc Comment
 *
 * PHP version 7.3.18
 *
 * @category  Safeware
 * @package   Safeware_AdditionalPayment
 * @author    Rceipt Pharmacy <rceiptPharmacy@gmail.com>
 * @copyright 2021-2022 Squiz Pty Ltd (ABN 77 084 670 600)
 * @license   https://www.safeware.com/ Safeware License
 * @link      https://stagingpayment.recepthealthcare.com
 */

namespace Pharmacy\AdditionalPayment\Observer;

use Pharmacy\AdditionalPayment\Helper\Data;
use Pharmacy\AdditionalPayment\Helper\ApiRequest;
use Magento\Framework\Session\SessionManagerInterface;

class OrderDataObserver implements \Magento\Framework\Event\ObserverInterface
{
    /**
     * @var Data
     */
    protected $datahelper;

    /**
     * @var ApiRequest
     */
    protected $apirequesthelper;

    /**
     * Construct Params
     * 
     * @param Data                    $dataHelper
     * @param SessionManagerInterface $_coreSession
     * @param ApiRequest              $ApiRequestHelper
     */
    public function __construct(
        Data $dataHelper,
        SessionManagerInterface $_coreSession,
        ApiRequest $ApiRequestHelper
    ) {
        $this->datahelper          = $dataHelper;
        $this->_coreSession         = $_coreSession;
        $this->apirequesthelper    = $ApiRequestHelper;
    } 

    /**
     * @param Observer $observer
     * @return $this;
     */
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $session = $this->_coreSession->getPaymentValue();
        $ccid=$this->_coreSession->getCcId();
        $orderId =   $this->_coreSession->getOrderId();
        if($session=='thirdparty') {
            $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/push_api_response.log');
            $logger = new \Zend\Log\Logger();
            $logger->addWriter($writer);
            $logger->info(__('start pusshing'));
        
            //get current shipping address
            $order          = $observer->getEvent()->getOrder();
            $order_ids      = $observer->getEvent()->getOrderIds();
            $order_id       = $order_ids[0];
            $apiResponse    = $this->apirequesthelper->OrderPaymentInfodata($order_id);
            $apidata=$this->apirequesthelper->dataRequest($ccid, $orderId);
            $apiAdditionalAddressResponse=$this->apirequesthelper->AddSecondaryShippingAddress($order, $apidata);
            $logger->info(print_r($apiResponse, true));
        }
    }
}
