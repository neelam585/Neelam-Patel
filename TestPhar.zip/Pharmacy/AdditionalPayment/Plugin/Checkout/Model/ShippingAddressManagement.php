<?php
/**
 * AdditionalPayment Doc Comment
 *
 * PHP version 7.2
 *
 * @category  Safeware
 * @package   Safeware_AdditionalPayment
 * @author    Rceipt Pharmacy <rceiptPharmacy@gmail.com>
 * @copyright 2021-2022 Squiz Pty Ltd (ABN 77 084 670 600)
 * @license   https://www.safeware.com/ Safeware License
 * @link      https://stagingpayment.recepthealthcare.com
 */

namespace Pharmacy\AdditionalPayment\Plugin\Checkout\Model;

use Magento\Framework\UrlInterface;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Message\ManagerInterface;

class ShippingAddressManagement
{
    /**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $quoteRepository;
    /**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */

    protected $orderCollectionFactory;
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */

    protected $storeManager;
    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */

    protected $messageManager;

    public function __construct(
        QuoteRepository $quoteRepository,
        CollectionFactory $orderCollectionFactory,
        StoreManagerInterface $storeManager,
        ManagerInterface $messageManager
    ) {
        $this->quoteRepository          = $quoteRepository;
        $this->orderCollectionFactory   = $orderCollectionFactory;
        $this->storeManager             = $storeManager;
        $this->messageManager          = $messageManager;
    }

    /**
     * @param \Magento\Checkout\Model\ShippingInformationManagement $subject
     * @param $cartId
     * @param \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     */

    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
        $quote      = $this->quoteRepository->getActive($cartId);
        $ccid       = $quote->getCcId();
        $accountId  = $quote->getAccountId();

        $customerOrder  = $this->orderCollectionFactory->create()
            ->addFieldToFilter('account_id', $accountId)
            ->addFieldToFilter('cc_id', $ccid);

        if($customerOrder->getTotalCount() > 0) {
            throw new AlreadyExistsException(
                __(
                    "Payment for this order has already been processed can't proceed to place order again."
                )
            );
            exit;
        }
    }
}
