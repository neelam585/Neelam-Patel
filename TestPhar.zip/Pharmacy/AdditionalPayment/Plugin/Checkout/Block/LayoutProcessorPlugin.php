<?php
/**
 * AdditionalPayment Doc Comment
 *
 * PHP version 7.3.18
 *
 * @category  Safeware
 * @package   Safeware_AdditionalPayment
 * @author    Rceipt Pharmacy <rceiptPharmacy@gmail.com>
 * @copyright 2021-2022 Squiz Pty Ltd (ABN 77 084 670 600)
 * @license   https://www.safeware.com/ Safeware License
 * @link      https://stagingpayment.recepthealthcare.com
 */

namespace Pharmacy\AdditionalPayment\Plugin\Checkout\Block;

use Magento\Checkout\Block\Checkout\LayoutProcessor;
use Magento\Framework\Session\SessionManagerInterface;

class LayoutProcessorPlugin
{

   
    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */

    public $coreSession;
    /**
     * Constructor params
     * 
     * @param SessionManagerInterface $coreSession
     */
    
    public function __construct(
        SessionManagerInterface $coreSession
    ) {
            $this->coreSession = $coreSession;   
    }
    public function afterProcess(
        LayoutProcessor $subject,
        $jsLayout
    ) {
        // get Payment value from session
        $session = $this->coreSession->getPaymentValue();
        
        if($session=='thirdparty') {    //Apply Discount Code unset 
            unset(
                $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']
                ['children']['payment']['children']['afterMethods']['children']['discount']
            );
              // Remove product image from checkout page
              unset(
                  $jsLayout['components']['checkout']['children']['sidebar']['children']['summary']
                  ['children']['cart_items']['children']['details']['children']['thumbnail']
              );
        }
        else
        {   //Apply Discount Code set 
            $jsLayout['components']['checkout']['children']['steps']['children']['billing-step']
              ['children']['payment']['children']['afterMethods']['children']['discount'];
            // Show product image from checkout page
            $jsLayout['components']['checkout']['children']['sidebar']['children']['summary']
              ['children']['cart_items']['children']['details']['children']['thumbnail'];   
            // unset delivery date				
            unset($jsLayout['components']['checkout']['children']['sidebar']['children']['custom_sidebar']);    
        }
           
        return $jsLayout;
    }
}
