<?php
/**
 * AdditionalPayment Doc Comment
 *
 * PHP version 7.3.18
 *
 * @category  Safeware
 * @package   Safeware_AdditionalPayment
 * @author    Rceipt Pharmacy <rceiptPharmacy@gmail.com>
 * @copyright 2021-2022 Squiz Pty Ltd (ABN 77 084 670 600)
 * @license   https://www.safeware.com/ Safeware License
 * @link      https://stagingpayment.recepthealthcare.com
 */

use Magento\Framework\Component\ComponentRegistrar;
/**
 * AdditionalPayment Doc Comment
 */
ComponentRegistrar::register(ComponentRegistrar::MODULE, 'Pharmacy_AdditionalPayment', __DIR__);
