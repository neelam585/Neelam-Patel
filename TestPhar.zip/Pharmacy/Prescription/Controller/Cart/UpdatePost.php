<?php
/** 
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Pharmacy\Prescription\Controller\Cart;

use Magento\Checkout\Model\Cart\RequestQuantityProcessor;
use Magento\Framework\App\Action\HttpPostActionInterface;
use Magento\Framework\App\Action\HttpGetActionInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Pharmacy\Prescription\Helper\Data;

/**
 * Post update shopping cart.
 */
class UpdatePost extends \Magento\Checkout\Controller\Cart implements HttpGetActionInterface, HttpPostActionInterface
{
    /**
     * @var RequestQuantityProcessor
     */
    protected $storeManager;
    protected $_quoteRepo;
    protected $checkoutSession;
    private $quantityProcessor;
    private $filesystem;
    private $fileUploaderFactory;

    /** 
	 * @var Pharmacy\Prescription\Helper\Data
	*/
	protected $_helperData;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator
     * @param \Magento\Checkout\Model\Cart $cart
     * @param Pharmacy\Prescription\Helper\Data $helperData
     * @param RequestQuantityProcessor $quantityProcessor
     */
    public function __construct(
         \Magento\Quote\Model\QuoteRepository $quoteRepo,
        \Magento\Framework\App\Action\Context $context,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Data\Form\FormKey\Validator $formKeyValidator,
        \Magento\Checkout\Model\Cart $cart,
        \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
        \Magento\Framework\Filesystem $filesystem,
        Data $helperData,
        RequestQuantityProcessor $quantityProcessor = null
    ) {
        parent::__construct($context,$scopeConfig,$checkoutSession,$storeManager,$formKeyValidator,$cart);
        $this->storeManager=$storeManager;
        $this->_quoteRepo = $quoteRepo;
        $this->checkoutSession = $checkoutSession;
        $this->fileUploaderFactory = $fileUploaderFactory;
        $this->filesystem = $filesystem;
        $this->_helperData 	= $helperData;
        $this->quantityProcessor = $quantityProcessor ?: $this->_objectManager->get(RequestQuantityProcessor::class);
    }

    /**
     * Empty customer's shopping cart
     *
     * @return void
     */
    protected function _emptyShoppingCart()
    {
        try {
            $this->cart->truncate()->save();
        } catch (\Magento\Framework\Exception\LocalizedException $exception) {
            $this->messageManager->addErrorMessage($exception->getMessage());
        } catch (\Exception $exception) {
            $this->messageManager->addExceptionMessage($exception, __('We can\'t update the shopping cart.'));
        }
    }

    /**
     * Update customer's shopping cart
     *
     * @return void
     */
    protected function _updateShoppingCart()
    {
        try {
            $cartData = $this->getRequest()->getParam('cart');
            if (is_array($cartData)) {
                if (!$this->cart->getCustomerSession()->getCustomerId() && $this->cart->getQuote()->getCustomerId()) {
                    $this->cart->getQuote()->setCustomerId(null);
                }
                $cartData = $this->quantityProcessor->process($cartData);
                $cartData = $this->cart->suggestItemsQty($cartData);
                $this->cart->updateItems($cartData)->save();
            }
        } catch (\Magento\Framework\Exception\LocalizedException $e) {
            $this->messageManager->addErrorMessage(
                $this->_objectManager->get(\Magento\Framework\Escaper::class)->escapeHtml($e->getMessage())
            );
        } catch (\Exception $e) {
            $this->messageManager->addExceptionMessage($e, __('We can\'t update the shopping cart.'));
            $this->_objectManager->get(\Psr\Log\LoggerInterface::class)->critical($e);
        }

        /** Saving presciption */
        $this->saveUploadedPrescription();
    }

    /**
     * Update shopping cart data action
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {         
        if (!$this->_formKeyValidator->validate($this->getRequest())) {
            return $this->resultRedirectFactory->create()->setPath('*/*/');
        }

        $updateAction = (string)$this->getRequest()->getParam('update_cart_action');

        switch ($updateAction) {
            case 'empty_cart':
                $this->_emptyShoppingCart();
                break;
            case 'update_qty':
                $this->_updateShoppingCart();
                break;
            default:
                $this->_updateShoppingCart();
        }

        return $this->_goBack();
    }

    public function saveUploadedPrescription()
    {   
        $files     = $this->getRequest()->getFiles('prescription_upload_file');
        $quoteId   = $this->checkoutSession->getQuote()->getId();
        $quote     = $this->_quoteRepo->get($quoteId);
        if(is_array($files)) {
            foreach($quote->getAllVisibleItems() as $itemq)
            {
                $itemID = $itemq->getId();
                $allowed_file_extension = ["png", "jpg", "jpeg", "gif", "pdf"];
                $filename = $files[$itemID]['name'];
                $file_extension = pathinfo($filename, PATHINFO_EXTENSION);              
                if(isset($files[$itemID]) && $filename != Null)
                {
                    if(in_array($file_extension, $allowed_file_extension)) {
                        try { 
                            $itemq->setData('prescription_img', $filename);
                            $itemq->save();

                            $mediaDir = $this->filesystem->getDirectoryRead(DirectoryList::MEDIA)->getAbsolutePath();
                            $mediapath = $this->_mediaBaseDirectory = rtrim($mediaDir, '/');
                            
                            $uploader = $this->fileUploaderFactory->create(['fileId' => $files[$itemID]]);
                            $uploader->setAllowedExtensions($allowed_file_extension);
                            $uploader->setAllowRenameFiles(true);
                            $path   = $mediapath . '/image/';
                            $result = $uploader->save($path);

                            $this->_helperData->setPreMessage('Your prescription has been uploaded successfully');
                            $this->_helperData->setMessageClass('message-success success message');

                        } catch (\Magento\Framework\Exception\LocalizedException $e) {
                            $this->_helperData->setPreMessage($e->getMessage());
                            $this->_helperData->setMessageClass('message-error error message');
                            $this->messageManager->addErrorMessage(__($e->getMessage()));
                        }
                
                    } else {
                        $this->_helperData->setPreMessage('Please upload valid file in jpg, jpeg, png, gif and pdf format only');
                        $this->_helperData->setMessageClass('message-error error message');
                        $this->messageManager->addErrorMessage(__('Please upload valid file in jpg, jpeg, png, gif and pdf format only.'));
                    }
                }
            }
        }
    }
}
