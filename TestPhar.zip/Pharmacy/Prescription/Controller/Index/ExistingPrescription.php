<?php
namespace Pharmacy\Prescription\Controller\Index;

class ExistingPrescription extends \Magento\Framework\App\Action\Action
{
	/**
     * @var \Pharmacy\Prescription\Helper\Data
     */
	protected $_datahelper;
	/**
     * @var \Magento\Quote\Model\QuoteRepository
     */
	protected $_quoteRepo;
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	protected $_pageFactory;
	/**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;
	/**
     * Constructor params
     * 
     * @param Magento\Framework\App\Action\Context $context
     * @param Pharmacy\Prescription\Helper\Data $dataHelper
	 * @param Magento\Quote\Model\QuoteRepository $quoteRepo
	 * @param Magento\Checkout\Model\Session $checkoutSession
     * @param Magento\Framework\View\Result\PageFactory $pageFactory
     */
	public function __construct(
		\Pharmacy\Prescription\Helper\Data $dataHelper,
		\Magento\Framework\App\Action\Context $context,
        \Magento\Quote\Model\QuoteRepository $quoteRepo,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_datahelper = $dataHelper;
		$this->_quoteRepo = $quoteRepo;
		$this->checkoutSession = $checkoutSession;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{    
		$mediaUrl= $this->_datahelper->getMediaUrl().'image/';
	     
		 $post = $this->getRequest()->getPostValue();
		 $quoteId=$this->checkoutSession->getQuote()->getId();
         $quotemodel = $this->_quoteRepo->get($quoteId);

         foreach($quotemodel->getAllVisibleItems() as $itemq)
        {
           if($itemq->getId()==$post['itemId'])
         	{
                $image=$itemq->setData('prescription_img', $post['img']);
                $image->save();
                $pos = strpos($image->getPrescriptionImg(), '.pdf');
                if ($pos === false)
                {
                	echo $mediaUrl.$image->getPrescriptionImg();
                } 
                else 
                {
                	echo $mediaUrl."defaultpdf.png";
                }
            }
        }
	}
}
