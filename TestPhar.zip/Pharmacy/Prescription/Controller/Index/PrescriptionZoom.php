<?php
namespace Pharmacy\Prescription\Controller\Index;

class PrescriptionZoom extends \Magento\Framework\App\Action\Action
{
	/**
     * @var \Pharmacy\Prescription\Helper\Data
     */
	protected $_datahelper; 
	/**
     * @var \Magento\Quote\Model\QuoteRepository
     */
	protected $_quoteRepo;
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	protected $_pageFactory;
	/**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;
	/**
     * Constructor params
     * 
     * @param Pharmacy\Prescription\Helper\Data $dataHelper
	 * @param Magento\Framework\App\Action\Context $context
	 * @param Magento\Quote\Model\QuoteRepository $quoteRepo
	 * @param Magento\Checkout\Model\Session $checkoutSession
     * @param Magento\Framework\View\Result\PageFactory $pageFactory
     */
	public function __construct(
		\Pharmacy\Prescription\Helper\Data $dataHelper,
		\Magento\Framework\App\Action\Context $context,
        \Magento\Quote\Model\QuoteRepository $quoteRepo,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_datahelper = $dataHelper;
		$this->_quoteRepo = $quoteRepo;
		$this->checkoutSession = $checkoutSession;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{ 
		$post = $this->getRequest()->getPostValue();
		$mediaUrl= $this->_datahelper->getMediaUrl().'image/';
		$quoteId=$this->checkoutSession->getQuote()->getId();
		$quotemodel = $this->_quoteRepo->get($quoteId);
        foreach($quotemodel->getAllVisibleItems() as $itemq)
        {
         	if($itemq->getId()==$post['item_id'])
         	{
                $image=$itemq->getData('prescription_img');
                echo "<img src='$mediaUrl".$image."'>";
                exit;
            }  
        }
	}
}
