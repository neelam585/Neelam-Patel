<?php
namespace Pharmacy\Prescription\Controller\Index;

class PrescriptionNotRequired extends \Magento\Framework\App\Action\Action
{
	/**
     * @var \Pharmacy\Prescription\Helper\Data
     */
	protected $_datahelper;
	/**
     * @var \Magento\Framework\View\Result\PageFactory
     */
	protected $_pageFactory;
	
    /** Constructor Params
     * @param \Pharmacy\Prescription\Helper\Data $dataHelper
     * @param \Magento\Framework\View\Result\PageFactory $pageFactory
     */
	public function __construct(
        \Pharmacy\Prescription\Helper\Data $dataHelper,
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_datahelper = $dataHelper;
		$this->_pageFactory = $pageFactory; 
		return parent::__construct($context);
	}

	public function execute()
	{  
        $productId = $this->getRequest()->getPostValue('pid');
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance(); 
        $productRepository = $objectManager->get('\Magento\Catalog\Model\ProductRepository');
        $productObj = $productRepository->getById($productId);
        $productObj->getPrescription();
        $productAttributeLabel= $this->_datahelper->getOptionLabelByValue('prescription', $productObj->getPrescription()); 
		if($productAttributeLabel=='Yes') 
		{
			echo 1;
		} 
		else 
		{
			echo 2;
		}
	
	}
}
