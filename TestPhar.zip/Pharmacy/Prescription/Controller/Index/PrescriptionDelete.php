<?php
namespace Pharmacy\Prescription\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Filesystem;
use Magento\Quote\Model\QuoteRepository;
use Magento\Checkout\Model\Session; 
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Request\Http;
use Magento\Framework\Controller\Result\JsonFactory;

class PrescriptionDelete extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;
	/**
     * @var \Magento\Framework\Filesystem\Driver\File
     */
    protected $_file;
	/**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $quoteRepo;
	 /**
     * @var \Magento\Checkout\Model\Session
     */
    protected $checkoutSession;
	/**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $_request;
	/**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;
    
    /** Constructor Params
     * @param \Magento\Framework\App\Action\Context $context
     * @param \Magento\Framework\Filesystem $_filesystem
     * @param \Magento\Framework\App\Request\Http $_request
     * @param \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory
     * @param \Magento\Quote\Model\QuoteRepository $quoteRepo
     * @param \Magento\Checkout\Model\Session $checkoutSession
     * @param \Magento\Framework\Filesystem\Driver\File $file
     */
    public function __construct(
        Context $context,
        Filesystem $_filesystem,
        Http $_request,
        JsonFactory $resultJsonFactory,
        QuoteRepository $quoteRepo,
        Session $checkoutSession,
        File $file
    )
    {
        parent::__construct($context);
        $this->_filesystem = $_filesystem;
        $this->_file = $file;
        $this->quoteRepo = $quoteRepo;
        $this->checkoutSession = $checkoutSession;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_request = $_request;
    }

    public function execute()
    {
        $resultJson = $this->resultJsonFactory->create();
        $itemId = $this->_request->getParam('id');
        $quoteId = $this->checkoutSession->getQuote()->getId();
        $quoteModel = $this->quoteRepo->get($quoteId);
       
        foreach($quoteModel->getAllVisibleItems() as $itemq) {
            if ($itemId == $itemq->getId()) {
         	      //file image remove
                $fileName = $itemq->getData('prescription_img');
    		    $itemq->setData('prescription_img', '');
                $itemq->save();
                exit();
            }
        }
        return $resultJson->setData(['result' => 'Good Bye']);
    }
}
