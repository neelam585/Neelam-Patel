var config =
    {
        map:
        {
           '*':
               {
                'Magento_Catalog/js/catalog-add-to-cart': 'Pharmacy_Prescription/js/catalog-add-to-cart',
                'Magento_Checkout/js/checkout-loader': 'Pharmacy_Prescription/js/checkout-loader'
               }
        }
    };
	