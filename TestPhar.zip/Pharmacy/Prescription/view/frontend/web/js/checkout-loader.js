/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
define([
    'rjsResolver',
    'jquery'
], function (resolver, $) {
    'use strict';

    /**
     * Removes provided loader element from DOM.
     *
     * @param {HTMLElement} $loader - Loader DOM element.
     */
    function hideLoader($loader) {
        $loader.parentNode.removeChild($loader);
    }

    /**
     * Initializes assets loading process listener.
     *
     * @param {Object} config - Optional configuration
     * @param {HTMLElement} $loader - Loader DOM element.
     */
    function init(config, $loader) {
        resolver(hideLoader.bind(null, $loader));
        convertMobileToUS();
    }
	
	function convertMobileToUS() {
		$(document).on('keyup', '#shipping-new-address-form input[name="telephone"]', function(e) {
		var mobileNo = $("#shipping-new-address-form input[name='telephone']").val();
			if(mobileNo.length >= 10) {
				console.log('iff');
				var convertedNo = (mobileNo.replace(/(\d)(\d)(\d)(\d)(\d)(\d)(\d)(\d)(\d)(\d)/, '$1$2$3-$4$5$6-$7$8$9$10'));
				$("#shipping-new-address-form input[name='telephone']").val(convertedNo);
			}
		});
	}

    return init;
});
