	/**
	 * Copyright © Magento, Inc. All rights reserved.
	 * See COPYING.txt for license details.
	 */
    require([
        'mage/url',
        'jquery', 
        'Magento_Ui/js/modal/modal',
        'Magento_Ui/js/modal/confirm'
    ], function(urlBuilder, $, modal, confirmation) {
        
            $(document).ready(function() {
            var options = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                buttons: []
            };
            
            $(".view_id").on('click', function() {
                var item_id = $(this).attr('data_id');
                var image_src = $(this).prev("#img_hide-"+item_id).find('img').attr('src');
                
                var popup = modal(options, $('#popup-modal'));
                $(".popup-image").attr('src', image_src);
                $("#popup-modal").modal("openModal");
            });
            $('.modal-footer').hide();
        });
        
        $(document).ready(function() {
            var options1 = {
                type: 'popup',
                responsive: true,
                innerScroll: true,
                buttons: []
            };
            
            $(".view-zoom").on('click', function() {
                var item_id = $(this).attr('data_id');
                var image_src = $(this).parent().siblings("#img_hide-"+item_id).find('img').attr('src');
                var popup = modal(options1, $('#popup-modal'));
                $(".popup-image").attr('src', image_src);
                $("#popup-modal").modal("openModal");
            });
            $('.modal-footer').hide();
        });
        
        $(document).ready(function() {
        
         $(".img").change(function() {
                $('body').trigger('processStart');
                var customLink = urlBuilder.build('prescription/index/existingprescription');
                var option = $(".img:checked").val(); 
                var itemId = $(this).attr('item_id');
                $.ajax( {
                    type: "POST",
                    url: customLink,
                    data: {img: option, itemId: itemId},
                    success: function( data ) {
                        $('#img_hide-'+itemId).html("<img src="+data+">");  
                        $('.close121').trigger('click');  
                        $('#upload-status-'+itemId).text("Yes");
                        $('body').trigger('processStop');
                        $('#img_show'+itemId).show();
                        $('#'+itemId+'myBtn').show();
                     }
                });
            });
    
            $('.exit-prescription').on('click', function() {
                var item_id = $(this).attr('id');
                $('#exit-prescription-list-'+item_id).toggle();
            });
            
            $('.close121').on('click', function() {
                $(".toggle-class").css("display", "none");
            });
            
            $('.cross-id').on('click', function (e){
                e.preventDefault();
                var item_id = $(this).attr('data_id');
                var delete_prescription = urlBuilder.build('prescription/index/prescriptiondelete');
                confirmation({
                    title: 'Remove Prescription',
                    content: 'Are you sure you want to delete this prescription?',
                    actions: {
                        confirm: function () {
                            $.ajax({
                                showLoader: true,
                                url: delete_prescription,
                                data: {id: item_id},
                                type: "POST",
                                success: function (data) {
                                    $('#upload-status-'+item_id).text("No");
                                    $('#img_show'+item_id).hide();
                                    $('#'+item_id+'myBtn').hide();
                                    $('#exit-prescription-list-'+item_id).find(".img").prop("checked", false);
                                    $('#img_hide-'+item_id).html('<input type="file" class="uploadPres" name="prescription_upload_file['+item_id+']" value="" id="image"><input type="hidden" name="itemId" value="'+item_id+'">');
                                },
                                error: function (error) {

                                }
                            });
                        },

                        cancel: function () {
                            return false;
                        }
                    }
                });
            });
            // js for update cart page
            $('.uploadPres').on('change', function (e){
                e.preventDefault();
                
                confirmation({
                    title: 'Save Prescription',
                    content: 'Please click on Ok button to save uploaded prescription ?',
                    actions: {
                        confirm: function () {
                            $('.update').trigger('click');
                        },
                        cancel: function () {
                            return false;
                        }
                    }
                });
            });
        });
    });
