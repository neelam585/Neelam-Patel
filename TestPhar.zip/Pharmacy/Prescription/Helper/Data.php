<?php
 
namespace Pharmacy\Prescription\Helper;
 
class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
	/**
     * @var \Magento\Sales\Model\Order
     */
    protected $order;
	
	/**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;
	
	/**
     * @var \Magento\Sales\Model\Order\ItemFactory
     */
    protected $itemFactory;
	
	/**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $_quoteRepo;
	
	/**
     * @var \Magento\Customer\Model\Session
     */
    protected $customerSession;
	
	/**
     * @var \Magento\Sales\Model\ResourceModel\Order\CollectionFactory
     */
    protected $orderCollectionFactory;
	
	/**
 	 * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
 	 */ 
	protected $_productCollectionFactory;
	
	/**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;
	
	/**
     * @var \Magento\Catalog\Model\Session
     */
	protected $_modelSession;
	
    /**
     * @var \Magento\Framework\Registry
    */
    protected $_registry;
	
    /**
     * Constructor params
     * 
     * @param Magento\Framework\App\Helper\Context $context
     * @param Magento\Sales\Model\Order $order
     * @param Magento\Catalog\Model\ProductFactory $productFactory
     * @param Magento\Sales\Model\Order\ItemFactory $itemFactory
     * @param Magento\Quote\Model\QuoteRepository $quoteRepo
     * @param Magento\Customer\Model\Session $customerSession
     * @param Magento\Store\Model\StoreManagerInterface $storeManager
     * @param Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory
     * @param Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory
     * @param Magento\Catalog\Model\Session $modelSession
     * @param Magento\Framework\Registry $registry
     */
	public function __construct(
	    \Magento\Framework\App\Helper\Context $context,
        \Magento\Sales\Model\Order $order,
        \Magento\Catalog\Model\ProductFactory $productFactory,
        \Magento\Sales\Model\Order\ItemFactory $itemFactory,
        \Magento\Quote\Model\QuoteRepository $quoteRepo,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory $productCollectionFactory,
		\Magento\Catalog\Model\Session $modelSession,
        \Magento\Framework\Registry $registry
    ) {
        parent::__construct($context);
        $this->order 			= $order;
        $this->productFactory 	= $productFactory;
        $this->customerSession 	= $customerSession;
        $this->itemFactory 		= $itemFactory;
        $this->_quoteRepo 		= $quoteRepo;
        $this->orderCollectionFactory 		= $orderCollectionFactory;
        $this->_productCollectionFactory 	= $productCollectionFactory;
        $this->_storeManager 	= $storeManager;
		$this->_modelSession 	= $modelSession;
        $this->_registry        = $registry;
    }
	
	
	/**
     * get prescription value 
     *  
     * @return string
     * 
     */
	public function getProductPrescriptionValue($id)
	{
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $product = $objectManager->get('Magento\Catalog\Model\Product')->load($id);
        if(!is_null($product->getPrescription())){
           return $product->getPrescription(); 
        }

        return '';
	}
	
	/**
     * get media url
     *  
     * @return string
     * 
     */
    public function getMediaUrl(){
       return $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
    }
	
	/**
     * get base url
     *  
     * @return sting
     * 
     */
     public function getBaseUrl(){
       return $this->_storeManager->getStore()->getBaseUrl();
    }
	
	/**
     * get prescription
     *  
     * @return int
     * 
     */
    public function getPrescriptionDetail(){
        return $this->customerSession->getCustomer()->getId();
    }
    
	/**
     * get order
     *  
     * @return array
     * 
     */
    public function getOrders($productId)
    {
		$prescData = [];
		if($this->isLoggedIn()) {
			$customerId 	= $this->customerSession->getCustomer()->getId();
			
			$customerOrder 	= $this->itemFactory->create()->getCollection();
			$customerOrder->getSelect()
							->joinLeft( array('sales_order'=> 'sales_order'), 
								'sales_order.entity_id = main_table.order_id', 
								array('main_table. prescription_img')
							);
			
			$customerOrder->addAttributeToSelect('*')
						 ->addFieldToFilter('sales_order.customer_id',['eq' => $customerId])
						 ->addFieldToFilter('main_table.product_id',['eq' => $productId]);
		  
			foreach ($customerOrder as $_item) {
                if (strpos($_item->getPrescriptionImg(), '.') !== false) {
				    $prescData[] = $_item->getPrescriptionImg();
                }
			}
		}

        return array_unique($prescData);
    }
    
	/**
     * check customer login
     *  
     * @return boolean
     * 
     */
    public function isLoggedIn(){
      if($this->customerSession->isLoggedIn()) {
        return true;
      }
	  
      return false;
    }
    
	/**
     * get option lable value 
     *  
     * @return string
     * 
     */
    public function getOptionLabelByValue($attributeCode,$optionId)
    {
        $product = $this->productFactory->create();
        $isAttributeExist = $product->getResource()->getAttribute($attributeCode); 
        $optionText = '';
        if ($isAttributeExist && $isAttributeExist->usesSource()) {
            $optionText = $isAttributeExist->getSource()->getOptionText($optionId);
        }
        return $optionText;
    }
	
	/**
     * set message
     *  
     * @return string
     * 
     */
	public function setPreMessage($msg) {
		return $this->_modelSession->setPrescriptionMessage($msg);
	}
	
	/**
     * get pree message 
     *  
     * @return string
     * 
     */
	public function getPreMessage() {
		return $this->_modelSession->getPrescriptionMessage();
	}
	
	/**
     * unset pree message 
     *  
     * @return string
     * 
     */
	public function unsPreMessage() {
		return $this->_modelSession->unsPrescriptionMessage();
	}
	
    /**
     * set message class
     *  
     * @return string
     * 
     */ 
    public function setMessageClass($class) {
		return $this->_modelSession->setMessageClass($class);
	}
    
	/**
     * get message class
     *  
     * @return string
     * 
     */
    public function getMessageClass() {
		return $this->_modelSession->getMessageClass();
	}

	/**
     * recet message class
     *  
     * @return string
     * 
     */ 
    public function resetMessageClass() {
		return $this->_modelSession->unsMessageClass();
	}

}