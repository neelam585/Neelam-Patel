<?php
 
namespace Frontend\Crud\Controller\Index;
use Magento\Framework\App\Filesystem\DirectoryList;
 
class Save extends \Magento\Framework\App\Action\Action
{
     protected $_pageFactory;
     protected $_postFactory;
     private $filesystem;
     private $fileUploaderFactory;
 
     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
          \Magento\Framework\Filesystem $filesystem,
          \Banner\Grid\Model\PostFactory $postFactory
          
     ){
          $this->_pageFactory = $pageFactory;
          $this->_postFactory = $postFactory;
          $this->fileUploaderFactory = $fileUploaderFactory;
          $this->filesystem = $filesystem;

          return parent::__construct($context);
     }
 
     public function execute()
     {
          if ($this->getRequest()->isPost()) {
          $post = $this->getRequest()->getPostValue();
       
          //$fileName = $post['image'];
          
        
          //
          $model = $this->_postFactory->create();

          $model->setData('title',$post['title']);

          $model->setData('image',$post['image']);

          $model->save();

          return $this->_redirect('crud/index/index');
          }
     }
}
