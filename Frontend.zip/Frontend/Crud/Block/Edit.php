<?php
 namespace Frontend\Crud\Block;
 
class Edit extends \Magento\Framework\View\Element\Template
{
     protected $_pageFactory;
     protected $_coreRegistry;
     protected $_postFactory;
 
     public function __construct(
          \Magento\Framework\View\Element\Template\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Magento\Framework\Registry $coreRegistry,
          \Banner\Grid\Model\PostFactory $postFactory,
          array $data = []
     ){
          $this->_pageFactory = $pageFactory;
          $this->_coreRegistry = $coreRegistry;
          $this->_postFactory = $postFactory;
          return parent::__construct($context,$data);
          //return parent::__construct($postFactory,$data);
     }
 
     public function execute()
     {
          return $this->_pageFactory->create();
     }
 
     public function getEditData()
     {
          //echo "aaaaadfsd";exit;
          $id = $this->_coreRegistry->registry('editId');
          $postData = $this->_postFactory->create();
          $result = $postData->load($id);
          //print_r($result);exit;
         $result = $result->getData();
          return $result;
     }
}
