<?php
namespace Frontend\Crud\Block;
 
use Magento\Framework\View\Element\Template;
use Banner\Grid\Model\PostFactory;
 
class Index extends Template
{
    protected $_postFactory;
 
    public function __construct(
        Template\Context $context,
        PostFactory $postFactory
    ) {
        parent::__construct($context);
        $this->_postFactory = $postFactory;
    }
 
    public function getTableData()
    {
        $contact = $this->_postFactory->create();
        $collection = $contact->getCollection();
        
        return $collection;
    }
}
