<?php
/**
 * Third party payment
 * Created By: Rohit Chauhan
 * Author: RceptPharmacy
 * Purpose: Payment from mobile app using maganto router
 */

namespace Pharmacy\AdditionalPayment\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Pharmacy\AdditionalPayment\Helper\ApiRequest;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Directory\Model\RegionFactory;
use Magento\Framework\Data\Form\FormKey;
use Magento\Checkout\Model\Cart;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Customer\Model\Session;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\Data\AddressInterfaceFactory; 
use Magento\Customer\Api\AddressRepositoryInterface; 
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Framework\App\Request\Http;
use Magento\Framework\UrlInterface;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Controller\ResultFactory;
use Magento\Quote\Model\QuoteRepository;

class Index extends Action
{   
    /**
     * @var \Pharmacy\AdditionalPayment\Helper\ApiRequest
     */
    protected $dataHelper;

    /**
     * @var \Magento\Catalog\Model\ProductFactory
     */
    protected $productFactory;

    /**
     * @var \Magento\Catalog\Api\ProductRepositoryInterface
     */
    protected $productRepository;

    /**
     * @var \Magento\Directory\Model\RegionFactory
     */
    protected $regionFactory;

    /**
     * @var \Magento\Customer\Api\Data\AddressInterfaceFactory
     */
    protected $dataAddressFactory;

    /**
     * @var \Magento\Customer\Api\AddressRepositoryInterface
     */
    protected $addressRepository;

    /**
     * @var \Magento\Customer\Api\CustomerRepositoryInterface
     */
    protected $customerRepo;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_session;

    /**
     * @var \Magento\Checkout\Model\Session as CheckoutSession
     */
    protected $checkoutSession;

    /**
     * @var \Magento\Framework\Session\SessionManagerInterface
     */
    protected $_coreSession;

    /**
     * @var \Magento\Customer\Model\CustomerFactory
     */
    protected $customerFactory;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    protected $formKey;
    
    /**
     * @var \Magento\Checkout\Model\Cart
     */
    protected $cart;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $storeManager;

    /**
     * @var \Magento\Framework\App\Request\Http
     */
    protected $request;

    /**
     * @var \Magento\Framework\Controller\Result\JsonFactory
     */
    protected $resultJsonFactory;

    /**
     * @var \Magento\Framework\Controller\ResultFactory
     */
    protected $resultFactory;

    /**
     * @var \Magento\Quote\Model\QuoteRepository
     */
    protected $_quoteRepo;

    /**
     * Constructor params
     * 
     * @param Context $context
     * @param ApiRequest $dataHelper
     * @param ProductFactory $productFactory
     * @param ProductRepositoryInterface $productRepository
     * @param RegionFactory $regionFactory
     * @param AddressInterfaceFactory $dataAddressFactory
     * @param AddressRepositoryInterface $addressRepository
     * @param CustomerRepositoryInterface $customerRepo
     * @param Session $_session
     * @param CheckoutSession $checkoutSession
     * @param SessionManagerInterface $_coreSession
     * @param CustomerFactory $customerFactory
     * @param StoreManagerInterface $storeManager
     * @param FormKey $formKey
     * @param Cart $cart
     * @param Http $request
     * @param JsonFactory $resultJsonFactory
     * @param ResultFactory $resultFactory
     * @param QuoteRepository $quoteRepo
     */
    public function __construct(
        Context $context,
        ApiRequest $dataHelper,
        ProductFactory $productFactory, 
        ProductRepositoryInterface $productRepository,
        RegionFactory $regionFactory,
        AddressInterfaceFactory $dataAddressFactory,
        AddressRepositoryInterface $addressRepository,
        CustomerRepositoryInterface $customerRepo,
        Session $_session, 
        CheckoutSession $checkoutSession,
        SessionManagerInterface $_coreSession,
        CustomerFactory $customerFactory,   
        StoreManagerInterface $storeManager,
        FormKey $formKey,
        Cart $cart,
        Http $request,
        JsonFactory $resultJsonFactory,
        ResultFactory $resultFactory,
        QuoteRepository $quoteRepo
        ) {
            $this->dataHelper           = $dataHelper;
            $this->productFactory       = $productFactory;
            $this->productRepository    = $productRepository;
            $this->regionFactory        = $regionFactory;
            $this->dataAddressFactory   = $dataAddressFactory;
            $this->addressRepository    = $addressRepository;
            $this->customerRepo         = $customerRepo;
            $this->_session             = $_session;
            $this->checkoutSession      = $checkoutSession;
            $this->_coreSession         = $_coreSession;
            $this->customerFactory      = $customerFactory;
            $this->storeManager         = $storeManager;
            $this->formKey              = $formKey;
            $this->cart                 = $cart;
            $this->request              = $request;
            $this->resultJsonFactory    = $resultJsonFactory;
            $this->resultFactory        = $resultFactory;
            $this->_quoteRepo           = $quoteRepo;
     
            parent::__construct($context);
    }
    
    /**
     * Execute additional payment process from Mobile APP
     */
    public function execute()
    {  
        $ccid    = $this->request->getParam('account_id');
        $orderId = $this->request->getParam('order_id');

        if($ccid && $orderId) {
            try {
				$this->setOrderIdCcidInSession($ccid, $orderId);
                $apiData = $this->apidata($ccid, $orderId);
                $this->customerCreate($apiData);
                $this->setSession($apiData);
                $this->emptyCart();
                $this->createProduct($apiData);
                $this->saveDataInQuoteTable($ccid, $orderId);
    
                $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                $storeUrl = $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_WEB);
                $redirect->setUrl($storeUrl.'checkout#shipping');
                
                return $redirect;
            } catch(\Exception $e) {
               echo "Error => ".$e->getMessage();
               exit;
            }
        } else {
            $quoteItems = $this->checkoutSession->getQuote()->getAllVisibleItems();
            $response   = count($quoteItems);
            $result     = $this->resultJsonFactory->create();
            $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
            $resultJson->setData($response);

            return $resultJson;
        }
    }

    /**
     * Getting API data based on cc_id and order_id from DPE 
     * 
     * @var $ccid
     * @var $orderId
     * 
     * @return Json||array
     */
    public function apidata($ccid, $orderId) {
        return $this->dataHelper->dataRequest($ccid, $orderId);
    }

    /**
     * Truncate active quote data
     * 
     * @return checkoutSession
     */
    public function emptyCart() {
        $_cart = $this->cart;
        $quoteItems = $this->checkoutSession->getQuote()->getAllVisibleItems();
        foreach($quoteItems as $item)
        {
            $_cart->removeItem($item->getId())->save(); 
        }
    }

    /**
     * Setting comapny logo into customer session
     * 
     * @var Json||array $apiData
     * @return session
     */
    public function setSession($apiData) {
        $this->_coreSession->start();
        // set Payment value in session
        $this->_coreSession->setPaymentValue('thirdparty');
        //set logo in session
        $this->_coreSession->setLog($apiData->logoPath);
    }

    /**
     * Setting cc_ic and order_id into customer session
     * 
     * @var cc_id $ccid
     * @var order_id $orderNumber
     * 
     * @return session
     */
    public function setOrderIdCcidInSession($ccid, $orderNumber) {
         // set orderId in session
        $this->_coreSession->setCcId($ccid);
        $this->_coreSession->setOrderNumber($orderNumber);
    }

    /**
     * Create customer if new otherwise use exiting and login
     * 
     * @var Json||array $apiData
     * @return boolean
     */
    public function customerCreate($apiData) {
        //for custommer login start
        $customerEmail = $apiData->email;
        $customerData = $this->customerFactory->create()->getCollection()
                ->addAttributeToSelect("*")
                ->addAttributeToFilter("email", array("eq" => $customerEmail))
                ->load();
        $customer_array = $customerData->getData();
       if(empty($customer_array))
       {
        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId(); 
        $customer   = $this->customerFactory->create();
        $customer->setWebsiteId($websiteId);
        // Preparing data for new customer
        $customer->setEmail($customerEmail); 
        $customer->setFirstname(strtolower($apiData->firstname));
        $customer->setLastname(strtolower($apiData->lastname));
        $customer->setPassword($this->dataHelper::DEFAULT_CUST_PASS);
        // Save data
        $customer->save();
        $customerId = $customer->getId(); 
        //customer login
        $this->customerLogin($apiData);
           
        /* save address as customer */
        $address = $this->dataAddressFactory->create();
        $address->setFirstname(strtolower($apiData->firstname));
        $address->setLastname(strtolower($apiData->lastname));
        $address->setTelephone($apiData->telephone);
        $address->setCity(strtolower($apiData->city));
        $address->setPostcode($apiData->postcode);
        //get regionId 
        $region     = $this->regionFactory->create();
        $resionID   = $region->loadByCode($apiData->region_code, $apiData->country_id)->getId();
        $address->setRegionId($resionID);
        $address->setCountryId($apiData->country_id);
        $street     = array(strtolower($apiData->street), " ", " ");
        $address->setStreet($street);
        
        $address->setIsDefaultShipping(1);
        $address->setIsDefaultBilling(1);
            
        $address->setCustomerId($customerId);
            
        try {
                $this->addressRepository->save($address);  
            }
        catch (\Exception $e) {
            echo 'Error in shipping/billing address.'.$e->getMessage();
            exit;
            }
        } else { 
            //customer Login
            $this->customerLogin($apiData);
        }
    }

    /**
     * Customer login using api data and if already login reset session
     * and login with current user
     * 
     * @var Json||array $apiData
     * @return boolean
     */
    public function customerLogin($apiData) {
        $customerEmail      = $apiData->email;
        if(!$this->_session->isLoggedIn()) {
            $customerRepo   = $this->customerRepo->get($customerEmail);  
            $customer       = $this->customerFactory->create()->load($customerRepo->getId());  
            $this->_session->setCustomerAsLoggedIn($customer);
        } else {
            $loggedInEmail     = $this->_session->getCustomer()->getEmail();
            if($loggedInEmail != $customerEmail) {
                //customer Logout
                $this->_session->logout();
                
                $customerRepo  = $this->customerRepo->get($customerEmail);  
                $customer      = $this->customerFactory->create()->load($customerRepo->getId());  
                $this->_session->setCustomerAsLoggedIn($customer);
            }
        }
        
        return true;
    }

    /**
     * Create product if not exist and addtocart
     * 
     * @var json||array
     * @return int
     */
    public function createProduct($apiData) {
        //for create product
        $count = 0;
        foreach($apiData->products as $_data) {    
            try {
                $_product       =  $this->productRepository->get($_data->sku);
                $_product       = $this->productFactory->create()->load($_product->getId());
                $_product->setPrice($_data->price);
                $_product->save();

            } catch(\Magento\Framework\Exception\NoSuchEntityException $e) {
                $_product = $this->productFactory->create();
                $_product->setSku($_data->sku);
                $_product->setName($_data->sku); // set your Product Name of Product
                $_product->setAttributeSetId(4); // set attribute id
                $_product->setStatus(1); // status enabled/disabled 1/0
                $_product->setWeight(''); // set weight of product
                $_product->setVisibility(1); // visibility of product (Not Visible Individually (1) / Catalog (2)/ Search (3)/ Catalog, Search(4))
                $_product->setWebsiteIds(array(1));
                $_product->setTaxClassId(0); // Tax class ID
                $_product->setTypeId('simple'); // type of product (simple/virtual/downloadable/configurable)
                $_product->setPrice($_data->price); // set price of product
                $_product->setStockData(
                    array(
                        'use_config_manage_stock' => 0,
                        'manage_stock' => 1,
                        'is_in_stock' => 1,
                        'min_sale_qty' => 1,
                        'max_sale_qty' => 100,
                        'qty' => 100
                    )
                );
                $_product->setPrescription(5);
                $_product->save();
            } catch (\Exception $e) {
                echo "Error in product creation =".$e->getMessage();
                exit;
            }

        try {
            $params = array(
                'form_key' => $this->formKey->getFormKey(),
                'product' => $_product->getId(), 
                'qty'   => $_data->qty
            );                   
            $this->cart->addProduct($_product, $params);
            $this->cart->save();
        } catch(\Exception $e) {
            echo "Error in product addtocart =".$e->getMessage();
            exit;
        }
            $count++;
        }

        return $count;
    }

    /**
     * Save ccid and orderid in to active quote
     * 
     * @var cc_id $ccid
     * @var order_id $orderNumber
     * 
     * @return boolean
     */
    public function saveDataInQuoteTable($ccid, $orderNumber) {
        $quoteId            = $this->checkoutSession->getQuote()->getId();
        
        if($quoteId) {

            $quotemodel     = $this->_quoteRepo->get($quoteId);
            $quotemodel     = $quotemodel->setData('account_id', $orderNumber);
            $quotemodel     = $quotemodel->setData('cc_id', $ccid);

            $quotemodel->save();
        }
    }
}
