<?php
/**
 * Third party payment
 * Created By: Rohit Chauhan
 * Author: RceptPharmacy
 * Purpose: Payment from mobile app using maganto router
 */

namespace Pharmacy\AdditionalPayment\Controller\Index;

use Pharmacy\AdditionalPayment\Helper\ApiRequest;
use Magento\Framework\App\Action\Action;
use Magento\Directory\Model\RegionFactory;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Data\Form\FormKey;
use Magento\Checkout\Model\Cart;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Customer\Model\CustomerFactory;
use Magento\Framework\Session\SessionManagerInterface;
use Magento\Customer\Model\Session;
use Magento\Checkout\Model\Session as CheckoutSession;
use Magento\Customer\Api\Data\AddressInterfaceFactory; 
use Magento\Customer\Api\AddressRepositoryInterface; 
use Magento\Customer\Api\CustomerRepositoryInterface;
use Magento\Catalog\Model\ProductFactory;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\App\Request\Http;
use Magento\Framework\UrlInterface;
use Magento\Framework\Controller\ResultFactory;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Quote\Model\QuoteRepository;

class Index extends Action
{   
    protected $dataHelper;
    protected $productFactory;
    protected $productRepository;
    protected $regionFactory;
    protected $dataAddressFactory;
    protected $addressRepository;
    protected $customerRepo;
    protected $_session;
    protected $checkoutSession;
    protected $_coreSession;
    protected $customerFactory;
    protected $formKey;   
    protected $cart;
    protected $product;
    protected $storeManager;
    protected $request;
    protected $resultJsonFactory;
    protected $resultFactory;
    protected $_quoteRepo;

    public function __construct(
        Context $context,
        ApiRequest $dataHelper,
        ProductFactory $productFactory, 
        RegionFactory $regionFactory,
        ProductRepositoryInterface $productRepository,
        AddressInterfaceFactory $dataAddressFactory,
        AddressRepositoryInterface $addressRepository,
        CustomerRepositoryInterface $customerRepo,
        Session $_session, 
        CheckoutSession $checkoutSession,
        SessionManagerInterface $_coreSession,
        CustomerFactory $customerFactory,   
        StoreManagerInterface $storeManager,
        FormKey $formKey,
        Cart $cart,
        Http $request,
        JsonFactory $resultJsonFactory,
        ResultFactory $resultFactory,
        QuoteRepository $quoteRepo
        ) {
            $this->dataHelper           = $dataHelper;
            $this->productFactory       = $productFactory;
            $this->productRepository    = $productRepository;
            $this->regionFactory        = $regionFactory;
            $this->dataAddressFactory   = $dataAddressFactory;
            $this->addressRepository    = $addressRepository;
            $this->customerRepo         = $customerRepo;
            $this->_session             = $_session;
            $this->checkoutSession      = $checkoutSession;
            $this->_coreSession         = $_coreSession;
            $this->customerFactory      = $customerFactory;
            $this->storeManager         = $storeManager;
            $this->formKey              = $formKey;
            $this->cart                 = $cart;
            $this->request              = $request;
            $this->resultJsonFactory    = $resultJsonFactory;
            $this->resultFactory        = $resultFactory;
            $this->_quoteRepo           = $quoteRepo;
     
            parent::__construct($context);
    }
    
    public function execute()
    {  
        $ccid    = $this->request->getParam('account_id');
        $orderId = $this->request->getParam('order_id');

        if($ccid && $orderId) {
            try {
                $apiData = $this->apidata($ccid, $orderId);
                $this->customerCreate($apiData);
                $this->setSession($apiData);
                $this->emptyCart();
                $this->createProduct($apiData);
                $this->saveDataInQuoteTable($ccid, $orderId);
    
                $redirect = $this->resultFactory->create(ResultFactory::TYPE_REDIRECT);
                $storeUrl = $this->storeManager->getStore()->getBaseUrl(UrlInterface::URL_TYPE_WEB);
                $redirect->setUrl($storeUrl.'checkout#shipping');
                
                return $redirect;
            } catch(\Exception $e) {
               echo "Error ".$e->getMessage();
               exit;
            }
        } else {
            $quoteItems = $this->checkoutSession->getQuote()->getAllVisibleItems();
            $response   = count($quoteItems);
            $result     = $this->resultJsonFactory->create();
            $resultJson = $this->resultFactory->create(ResultFactory::TYPE_JSON);
            $resultJson->setData($response);

            return $resultJson;
        }
    }

    public function apidata($ccid, $orderId) {
        return $this->dataHelper->dataRequest($ccid, $orderId);
    }

    public function emptyCart() {
        $_cart = $this->cart;
        $quoteItems = $this->checkoutSession->getQuote()->getAllVisibleItems();
        foreach($quoteItems as $item)
        {
            $_cart->removeItem($item->getId())->save(); 
        }
    }

    public function setSession($apiData) {
        $this->_coreSession->start();
        // set Payment value in session
        $this->_coreSession->setPaymentValue('thirdparty');
        //set logo in session
        $this->_coreSession->setLog($apiData->logoPath);
    }

    public function customerCreate($apiData) {
        //for custommer login start
        $customerEmail = $apiData->email;
        $customerData = $this->customerFactory->create()->getCollection()
                ->addAttributeToSelect("*")
                ->addAttributeToFilter("email", array("eq" => $customerEmail))
                ->load();
        $customer_array = $customerData->getData();
       if(empty($customer_array))
       {
        $websiteId  = $this->storeManager->getWebsite()->getWebsiteId(); 
        $customer   = $this->customerFactory->create();
        $customer->setWebsiteId($websiteId);
        // Preparing data for new customer
        $customer->setEmail($customerEmail); 
        $customer->setFirstname(strtolower($apiData->firstname));
        $customer->setLastname(strtolower($apiData->lastname));
        $customer->setPassword($this->dataHelper::DEFAULT_CUST_PASS);
        // Save data
        $customer->save();
        $customerId = $customer->getId(); 
        //customer login
        $this->customerLogin($apiData);
           
        /* save address as customer */
        $address = $this->dataAddressFactory->create();
        $address->setFirstname(strtolower($apiData->firstname));
        $address->setLastname(strtolower($apiData->lastname));
        $address->setTelephone($apiData->telephone);
        $address->setCity(strtolower($apiData->city));
        $address->setPostcode($apiData->postcode);
        //get regionId 
        $region     = $this->regionFactory->create();
        $resionID   = $region->loadByCode($apiData->region_code, $apiData->country_id)->getId();
        $address->setRegionId($resionID);
        $address->setCountryId($apiData->country_id);
        $street     = array(strtolower($apiData->street), " ", " ");
        $address->setStreet($street);
        
        $address->setIsDefaultShipping(1);
        $address->setIsDefaultBilling(1);
            
        $address->setCustomerId($customerId);
            
        try {
                $this->addressRepository->save($address);  
            }
        catch (\Exception $e) {
            echo 'Error in shipping/billing address.';
            exit;
            }
        } else { 
            //customer Login
            $this->customerLogin($apiData);
        }
    }
    public function customerLogin($apiData) {
        $customerEmail      = $apiData->email;
        if(!$this->_session->isLoggedIn()) {
            $customerRepo   = $this->customerRepo->get($customerEmail);  
            $customer       = $this->customerFactory->create()->load($customerRepo->getId());  
            $this->_session->setCustomerAsLoggedIn($customer);
        } else {
            $loggedInEmail     = $this->_session->getCustomer()->getEmail();
            if($loggedInEmail != $customerEmail) {
                //customer Logout
                $this->_session->logout();
                
                $customerRepo  = $this->customerRepo->get($customerEmail);  
                $customer      = $this->customerFactory->create()->load($customerRepo->getId());  
                $this->_session->setCustomerAsLoggedIn($customer);
            }
        }
        
        return true;
    }

    public function createProduct($apiData) {
        //for create product
        $count = 0;
        foreach($apiData->products as $_data) {    
            try {
                $_product       =  $this->productRepository->get($_data->sku);
                $_product       = $this->productFactory->create()->load($_product->getId());
                $_product->setPrice($_data->price);
                $_product->save();

            } catch(\Magento\Framework\Exception\NoSuchEntityException $e) {
                $_product = $this->productFactory->create();
                $_product->setSku($_data->sku);
                $_product->setName($_data->sku); // set your Product Name of Product
                $_product->setAttributeSetId(4); // set attribute id
                $_product->setStatus(1); // status enabled/disabled 1/0
                $_product->setWeight(''); // set weight of product
                $_product->setVisibility(1); // visibility of product (Not Visible Individually (1) / Catalog (2)/ Search (3)/ Catalog, Search(4))
                $_product->setWebsiteIds(array(1));
                $_product->setTaxClassId(0); // Tax class ID
                $_product->setTypeId('simple'); // type of product (simple/virtual/downloadable/configurable)
                $_product->setPrice($_data->price); // set price of product
                $_product->setStockData(
                    array(
                        'use_config_manage_stock' => 0,
                        'manage_stock' => 1,
                        'is_in_stock' => 1,
                        'min_sale_qty' => 1,
                        'max_sale_qty' => 100,
                        'qty' => 100
                    )
                );
                $_product->setPrescription(5);
                $_product->save();
            }

            $params = array(
                'form_key' => $this->formKey->getFormKey(),
                'product' => $_product->getId(), 
                'qty'   => $_data->qty
            );                   
            $this->cart->addProduct($_product, $params);
            $this->cart->save();

            $count++;
        }

        return $count;
    }

    public function saveDataInQuoteTable($ccid, $orderNumber) {
        $quoteId        = $this->checkoutSession->getQuote()->getId();
        if($quoteId) {
            $quotemodel     = $this->_quoteRepo->get($quoteId);
            $quotemodel     = $quotemodel->setData('account_id', $orderNumber);
            $quotemodel     = $quotemodel->setData('cc_id', $ccid);
            $quotemodel->save();
        }
    }
}
