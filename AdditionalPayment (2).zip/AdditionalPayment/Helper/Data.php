<?php
/**
 * Data helper
 */
namespace Pharmacy\AdditionalPayment\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\StoreManagerInterface;

class Data extends AbstractHelper
{
 	/**
 	 * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
 	 */ 
    protected $_coreSession;
    protected $orderCollectionFactory;
	protected $storeManager;
	
    /**
     * Constructor params
     * @param \Magento\Framework\Session\SessionManagerInterface $_coreSession
     */
	public function __construct(
        \Magento\Sales\Model\ResourceModel\Order\CollectionFactory $orderCollectionFactory,
        \Magento\Framework\Session\SessionManagerInterface $_coreSession,
		StoreManagerInterface $storeManager
    ){
        $this->_coreSession = $_coreSession; 
        $this->orderCollectionFactory = $orderCollectionFactory;
		$this->storeManager = $storeManager;		
    }

    /**
     * get payment value from session
     */
    public function getSessionValue()
    {
        return $this->_coreSession->getPaymentValue();
    }

    /**
     * get third party logo url from session
     */
    public function getLogoSessionValue()
    {    
        return $this->_coreSession->getLog();
    }

    /**
     * unset logo session
     */
    public function unsetLogoSession()
    {    
        return $this->_coreSession->unsLog();
    }

    /**
     * unset third party payment session
     */
    public function unsetSessionValue()
    {    
        //get logo from session
        return $this->_coreSession->unsPaymentValue();
    }
    /**
     * get orderId and ccid from session
     */
    public function getOrderIdSessionValue()
    {    
        return $this->_coreSession->getOrderNumber();
    }
    public function getCcIdSessionValue()
    {    
        return $this->_coreSession->getCcId();
    }
    /**
     * get customer order
     */
    public function getCustomerOrder(){ 
        $orderId= $this->getOrderIdSessionValue(); 
        $ccId 	= $this->getCcIdSessionValue();
		$result = "";		
       $customerOrder  = $this->orderCollectionFactory->create()
                            ->addFieldToFilter('account_id', $orderId)
                            ->addFieldToFilter('cc_id', $ccId);
        if($customerOrder->getTotalCount() > 0) {
            $orderId = $customerOrder->getFirstItem()->getEntityId();
            $storeUrl = $this->storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_WEB);
            $result = $storeUrl.'sales/order/print/order_id/'.$orderId;
        }
		
		return $result;
    }
    
}
