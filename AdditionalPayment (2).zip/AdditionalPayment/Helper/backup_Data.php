<?php
/**
 * Data helper
 */
namespace Pharmacy\AdditionalPayment\Helper;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
 	/**
 	 * @var \Magento\Catalog\Model\ResourceModel\Product\CollectionFactory
 	 */ 
    protected $_coreSession;
    
    /**
     * Constructor params
     * @param \Magento\Framework\Session\SessionManagerInterface $_coreSession
     */
	public function __construct(
        \Magento\Framework\Session\SessionManagerInterface $_coreSession
    ){
        $this->_coreSession = $_coreSession;  
    }

    /**
     * get payment value from session
     */
    public function getSessionValue()
    {
        return $this->_coreSession->getPaymentValue();
    }

    /**
     * get third party logo url from session
     */
    public function getLogoSessionValue()
    {    
        return $this->_coreSession->getLog();
    }

    /**
     * unset logo session
     */
    public function unsetLogoSession()
    {    
        return $this->_coreSession->unsLog();
    }

    /**
     * unset third party payment session
     */
    public function unsetSessionValue()
    {    
        //get logo from session
        return $this->_coreSession->unsPaymentValue();
    }
    
}
