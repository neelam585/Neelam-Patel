<?php
namespace Pharmacy\AdditionalPayment\Plugin\Checkout\Model;

use Magento\Framework\UrlInterface;
use Magento\Quote\Model\QuoteRepository;
use Magento\Sales\Model\ResourceModel\Order\CollectionFactory;
use Magento\Framework\Exception\AlreadyExistsException;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Message\ManagerInterface;

class ShippingAddressManagement
{
    protected $quoteRepository;
    protected $orderCollectionFactory;
    protected $storeManager;
    protected $_messageManager;

    public function __construct(
        QuoteRepository $quoteRepository,
        CollectionFactory $orderCollectionFactory,
        StoreManagerInterface $storeManager,
        ManagerInterface $messageManager
    ) {
        $this->quoteRepository          = $quoteRepository;
        $this->orderCollectionFactory   = $orderCollectionFactory;
        $this->storeManager             = $storeManager;
        $this->_messageManager          = $messageManager;
    }

    /**
     * @param \Magento\Checkout\Model\ShippingInformationManagement $subject
     * @param $cartId
     * @param \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
     */
    public function beforeSaveAddressInformation(
        \Magento\Checkout\Model\ShippingInformationManagement $subject,
        $cartId,
        \Magento\Checkout\Api\Data\ShippingInformationInterface $addressInformation
    ) {
        $quote      = $this->quoteRepository->getActive($cartId);
        $ccid       = $quote->getCcId();
        $accountId  = $quote->getAccountId();

        $customerOrder  = $this->orderCollectionFactory->create()
                            ->addFieldToFilter('account_id', $accountId)
                            ->addFieldToFilter('cc_id', $ccid);

        if($customerOrder->getTotalCount() > 0) {
            throw new AlreadyExistsException(__(
                        "Payment for this order has already been processed can't proceed to place order again."
                    )
            );
            exit;
        }
    }
}
