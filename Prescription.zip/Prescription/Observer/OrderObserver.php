<?php
namespace Pharmacy\Prescription\Observer;
 
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\Exception\LocalizedException;
use Magento\Framework\Message\ManagerInterface;
 
class OrderObserver implements ObserverInterface
{
	  protected $_datahelper;
    protected $messageManager;
    /**
     * @var \Magento\Framework\ObjectManagerInterface
     */
    protected $_objectManager;
 
    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlInterface;
    
    /**
     * [__construct ]
     *
     * @param \Magento\Framework\ObjectManagerInterface $objectManager
     * @param \Magento\Framework\UrlInterface           $urlInterface
     */
    public function __construct(
      \Magento\Framework\Message\ManagerInterface $messageManager,
    	\Pharmacy\Prescription\Helper\Data $dataHelper,
      \Magento\Framework\ObjectManagerInterface $objectManager,
      \Magento\Framework\UrlInterface $urlInterface
    ) {
      $this->messageManager = $messageManager;
    	$this->_datahelper = $dataHelper;
      $this->_objectManager = $objectManager;
      $this->_urlInterface = $urlInterface;
    }
 
    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
          $cart = $objectManager->get('\Magento\Checkout\Model\Cart'); 

          // retrieve quote items collection
          $itemsCollection = $cart->getQuote()->getItemsCollection();

          // get array of all items what can be display directly
          $itemsVisible = $cart->getQuote()->getAllVisibleItems();

          // retrieve quote items array
          $items = $cart->getQuote()->getAllItems();
          $status = false;
          foreach($items as $item) 
          {
	          $prescription = $this->_datahelper->getProductPrescriptionValue($item->getProductId());
            $productAttributeLabel= $this->_datahelper->getOptionLabelByValue('prescription',$prescription);
	          $img = $item->getPrescriptionImg();
	          if($productAttributeLabel == 'Yes' && $img == '')
              {
                 $status = true;
                 break; 
              }
          }
          
          if($status == true) 
          {
            $this->_datahelper->setMessageClass('message-error error message');
            $this->_datahelper->setPreMessage('One or more cart items required prescription Kindly upload before proceed to checkout.');
            $this->messageManager->addErrorMessage(__('One or more cart items required prescription Kindly upload before proceed to checkout.'));
            
            $url = $this->_urlInterface->getUrl('checkout/cart');
    	      $observer->getControllerAction()
                    ->getResponse()
                    ->setRedirect($url);
          }

    }
}
