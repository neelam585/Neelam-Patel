<?php
namespace Pharmacy\Prescription\Controller\Index;

use Magento\Framework\App\Action\Context;
use Magento\Framework\Filesystem\Driver\File;
use Magento\Framework\Filesystem;
use Magento\Quote\Model\QuoteRepository;
use Magento\Checkout\Model\Session; 
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Request\Http;
use Magento\Framework\Controller\Result\JsonFactory;

class PrescriptionDelete extends \Magento\Framework\App\Action\Action
{

    protected $_filesystem;
    protected $_file;
    protected $quoteRepo;
    protected $checkoutSession;
    protected $_request;
    protected $resultJsonFactory;

    public function __construct(
        Context $context,
        Filesystem $_filesystem,
        Http $_request,
        JsonFactory $resultJsonFactory,
        QuoteRepository $quoteRepo,
        Session $checkoutSession,
        File $file
    )
    {
        parent::__construct($context);
        $this->_filesystem = $_filesystem;
        $this->_file = $file;
        $this->quoteRepo = $quoteRepo;
        $this->checkoutSession = $checkoutSession;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->_request = $_request;
    }

    public function execute()
    {
        $resultJson = $this->resultJsonFactory->create();
        $itemId = $this->_request->getParam('id');
        $quoteId = $this->checkoutSession->getQuote()->getId();
        $quoteModel = $this->quoteRepo->get($quoteId);
       
        foreach($quoteModel->getAllVisibleItems() as $itemq) {
            if ($itemId == $itemq->getId()) {
         	      //file image remove
                $fileName = $itemq->getData('prescription_img');
    		    $itemq->setData('prescription_img', '');
                $itemq->save();
                exit();
            }
        }
        return $resultJson->setData(['result' => 'Good Bye']);
    }
}
