<?php
namespace Pharmacy\Prescription\Controller\Index;

class ExistingPrescription extends \Magento\Framework\App\Action\Action
{
	protected $_datahelper;
	protected $_quoteRepo;
	protected $_pageFactory;
    protected $checkoutSession;
	public function __construct(
		\Pharmacy\Prescription\Helper\Data $dataHelper,
		\Magento\Framework\App\Action\Context $context,
        \Magento\Quote\Model\QuoteRepository $quoteRepo,
		\Magento\Checkout\Model\Session $checkoutSession,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_datahelper = $dataHelper;
		$this->_quoteRepo = $quoteRepo;
		$this->checkoutSession = $checkoutSession;
		$this->_pageFactory = $pageFactory;
		return parent::__construct($context);
	}

	public function execute()
	{    
		$mediaUrl= $this->_datahelper->getMediaUrl().'image/';
	     
		 $post = $this->getRequest()->getPostValue();
		 $quoteId=$this->checkoutSession->getQuote()->getId();
         $quotemodel = $this->_quoteRepo->get($quoteId);

         foreach($quotemodel->getAllVisibleItems() as $itemq)
        {
           if($itemq->getId()==$post['itemId'])
         	{
                $image=$itemq->setData('prescription_img', $post['img']);
                $image->save();
                $pos = strpos($image->getPrescriptionImg(), '.pdf');
                if ($pos === false)
                {
                	echo $mediaUrl.$image->getPrescriptionImg();
                } 
                else 
                {
                	echo $mediaUrl."defaultpdf.png";
                }
            }
        }
	}
}
