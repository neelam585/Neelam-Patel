<?php
/**
 * Pharmacy_Prescription- Save uploaded prescription by user
 */
namespace Pharmacy\Prescription\Controller\Index;

use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\Filesystem;
use Pharmacy\Prescription\Helper\Data;

class Index extends \Magento\Framework\App\Action\Action
{
	/**
	 * @var \Magento\Quote\Model\QuoteRepository
	 */
	protected $_quoteRepo;

	/**
	 * @var \Magento\Store\Model\StoreManagerInterface
	 */
    protected $_storeManager;

	/**
	 * @var \Magento\Framework\View\Result\PageFactory
	 */
	protected $_pageFactory;

	/**
	 * @var \Magento\MediaStorage\Model\File\UploaderFactory
	 */
    protected $_fileUploaderFactory;

	/**
	 * @var \Magento\Quote\Model\QuoteFactory
	 */
	protected $quoteFactory;

	/**
	 * @var \Magento\Checkout\Model\Session
	 */
	protected $checkoutSession;

	/**
	 * @var \Magento\Framework\Filesystem
	 */
    protected $_filesystem;

	/** 
	 * @var \Magento\Framework\Message\ManagerInterface
	*/
    protected $messageManager;

	/** 
	 * @var Pharmacy\Prescription\Helper\Data
	*/
	protected $_helperData;

	/** Constructor Params
	 * @param \Magento\Framework\App\Action\Context $context
	 * @param \Magento\Quote\Model\QuoteRepository $quoteRepo
	 * @param \Magento\Store\Model\StoreManagerInterface $storeManager
	 * @param \Magento\Framework\View\Result\PageFactory $pageFactory
	 * @param \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory
	 * @param \Magento\Quote\Model\QuoteFactory $quoteFactory
	 * @param \Magento\Checkout\Model\Session $checkoutSession
	 * @param \Magento\Framework\Filesystem $filesystem
	 * @param Pharmacy\Prescription\Helper\Data $helperData
	 */
	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Quote\Model\QuoteRepository $quoteRepo,
		\Magento\Store\Model\StoreManagerInterface $storeManager,
		\Magento\Framework\View\Result\PageFactory $pageFactory,
	    \Magento\MediaStorage\Model\File\UploaderFactory $fileUploaderFactory,
	    \Magento\Quote\Model\QuoteFactory $quoteFactory,
	    \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Filesystem $filesystem,
		\Magento\Framework\Message\ManagerInterface $managerInterface,
		Data $helperData
	) {
		$this->_quoteRepo 		= $quoteRepo;
		$this->_pageFactory 	= $pageFactory;
		$this->quoteFactory 	= $quoteFactory;
		$this->checkoutSession 	= $checkoutSession;
		$this->_storeManager 	= $storeManager;
		$this->_fileUploaderFactory = $fileUploaderFactory;
		$this->_filesystem 		= $filesystem;
		$this->messageManager 	= $managerInterface;
		$this->_helperData 	= $helperData;
		return parent::__construct($context);
	}
 
	/** 
	 * execute prescription method 
	*/
	public function execute()
	{   
		$backUrl	= $this->getRequest()->getPostValue('backurl');
		$filename 	= $_FILES['custom_file']['name'];
		$size 		= $_FILES['custom_file']['size'];

		if ($size > 2000000) {
            
            $this->_helperData->setPreMessage('The file is too large. Allowed maximum size is 2MB.');
			$this->_helperData->setMessageClass('message-error error message');
			$this->messageManager->addErrorMessage(__('The file is too large. Allowed maximum size is 2MB.'));

	         $redirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
	 		 $redirect->setUrl($backUrl);
		     return $redirect;   

            //  Validate image file size end
	    }
		$allowed_file_extension = ["png", "jpg", "jpeg", "gif", "pdf"];
		
		// Get image file extension
		$file_extension = pathinfo($filename, PATHINFO_EXTENSION);
		
		$objectManager =  \Magento\Framework\App\ObjectManager::getInstance();        
		$catalogSession = $objectManager->get('\Magento\Catalog\Model\Session');

        if(in_array($file_extension, $allowed_file_extension))
        {
			$this->_helperData->setPreMessage('Your prescription has been uploaded successfully');
			$this->_helperData->setMessageClass('message-success success message');
		    $this->messageManager->addSuccessMessage(__('Your prescription has been uploaded successfully'));

	        $uploader 	= $this->_fileUploaderFactory->create(['fileId' => 'custom_file']);
	        $quoteId 	= $this->checkoutSession->getQuote()->getId();
	        $pathurl 	= $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA) . 'chirag/';
	        $mediaDir 	= $this->_filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA)->getAbsolutePath();
	        $mediapath 	= $this->_mediaBaseDirectory = rtrim($mediaDir, '/');

	        $uploader 	= $this->_fileUploaderFactory->create(['fileId' => 'custom_file']);
	        $uploader->setAllowedExtensions(['jpg', 'jpeg', 'gif', 'png','pdf']);
	        $uploader->setAllowRenameFiles(true);
	        $path 		= $mediapath . '/image/';
	        $result 	= $uploader->save($path);
	        $currenttime= date('Y-m-d H:i:s');
	        $quotemodel = $this->_quoteRepo->get($quoteId);
	      
	        $allids = [];
	        foreach($quotemodel->getAllVisibleItems() as $itemq)
	        {
	        	$allids[] = $itemq->getId();
	        }

		    $keyvalue = (count($allids)-1);
		    $i = 0;
		    foreach($quotemodel->getAllVisibleItems() as $itemq)
		    {
		        if($keyvalue==$i)
		        {
		            $itemq->setData('prescription_img', $_FILES['custom_file']['name']);
		            $itemq->save();
		        }
		        $i++;
		    }
			
	        $redirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
	        $redirect->setUrl($backUrl);

		    return $redirect;
			
		} else {
			$this->_helperData->setPreMessage('Please upload valid file in jpg, jpeg, png, gif and pdf format only');
			$this->_helperData->setMessageClass('message-error error message');
			$this->messageManager->addErrorMessage(__('Please upload valid file in jpg, jpeg, png, gif and pdf format only'));
	    
	        $redirect = $this->resultFactory->create(\Magento\Framework\Controller\ResultFactory::TYPE_REDIRECT);
	 		$redirect->setUrl($backUrl);
			
			return $redirect;
		}
	}
}
