<?php
namespace Pharmacy\Prescription\Plugin;

use Magento\Framework\Event\ObserverInterface;

 class  SaveImgInOrderItem
{   
    public function aroundConvert(
        \Magento\Quote\Model\Quote\Item\ToOrderItem $subject,
        \Closure $proceed,
        \Magento\Quote\Model\Quote\Item\AbstractItem $item,
        $additional = []
       ) {
       /** @var $orderItem Item */
        $orderItem = $proceed($item, $additional);
        $orderItem->setPrescriptionImg($item->getPrescriptionImg());
        return $orderItem;
        }
}
  